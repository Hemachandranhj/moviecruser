﻿namespace AuthenticationServer.API.Services
{
    using AuthenticationServer.API.Data.Repository;
    using AuthenticationServer.API.Models;

    public class UserService: IUserService
    {
        private readonly IUserRepository _repository;

        public UserService(IUserRepository repository)
        {
            _repository = repository;
        }

        /// <summary>
        /// validate user Logged in or not
        /// </summary>
        /// <param name="usrId"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public bool LoginByUser(string usrId, string password)
        {
            return _repository.LoginByUser(usrId, password);
        }

        /// <summary>
        /// Add a new user
        /// </summary>
        /// <param name="userDetail"></param>
        /// <returns></returns>
        public int Add(UserDetail userDetail)
        {
            return _repository.Add(userDetail);
        }        
    }
}

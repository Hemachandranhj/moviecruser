﻿namespace AuthenticationServer.API.Services
{
    using AuthenticationServer.API.Models;

    public interface IUserService
    {
        bool LoginByUser(string id, string password);
        int Add(UserDetail userDetails);
    }
}

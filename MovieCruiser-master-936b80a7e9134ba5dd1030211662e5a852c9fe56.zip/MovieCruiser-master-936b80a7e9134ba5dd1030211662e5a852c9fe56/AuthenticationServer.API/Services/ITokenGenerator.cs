﻿namespace AuthenticationServer.API.Services
{
    public interface ITokenGenerator
    {
        string GetJWTToken(string usrId);
    }
}

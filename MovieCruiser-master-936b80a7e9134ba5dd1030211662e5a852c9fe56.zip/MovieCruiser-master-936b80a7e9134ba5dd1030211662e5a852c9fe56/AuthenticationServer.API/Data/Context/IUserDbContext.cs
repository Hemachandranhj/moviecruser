﻿namespace AuthenticationServer.API.Data.Context
{
    using Microsoft.EntityFrameworkCore;
    using AuthenticationServer.API.Data.Entities;

    public interface IUserDbContext
    {
        DbSet<User> User { get; set; }

        int SaveChanges();
    }
}

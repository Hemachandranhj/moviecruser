﻿namespace AuthenticationServer.API.Data.Context
{
    using Microsoft.EntityFrameworkCore;
    using AuthenticationServer.API.Data.Entities;

    public class UserDbContext : DbContext, IUserDbContext
    {
        public UserDbContext() { }

        public UserDbContext(DbContextOptions<UserDbContext> contextOptions): base(contextOptions)
        {
            Database.EnsureCreated();
        }

        public DbSet<User> User { get; set; }
    }
}

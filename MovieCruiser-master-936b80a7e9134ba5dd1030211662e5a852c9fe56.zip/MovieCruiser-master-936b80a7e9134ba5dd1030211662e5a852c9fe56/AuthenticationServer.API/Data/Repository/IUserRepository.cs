﻿namespace AuthenticationServer.API.Data.Repository
{   
    using AuthenticationServer.API.Models;

    public interface IUserRepository
    {
        bool LoginByUser(string id, string password);
        int Add(UserDetail userDetails);
    }
}

﻿namespace AuthenticationServer.API.Data.Repository
{
    using System.Linq;
    using AuthenticationServer.API.Data.Context;
    using AuthenticationServer.API.Models;
    using AuthenticationServer.API.Data.Entities;
    using System;

    public class UserRepository: IUserRepository
    {
        private readonly IUserDbContext _context;

        public UserRepository(IUserDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// validate user Logged in or not
        /// </summary>
        /// <param name="usrId"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public bool LoginByUser(string usrId, string password)
        {
            var userDetail = _context.User.FirstOrDefault(usr => usr.UserId == usrId && usr.Password == password);
            return (userDetail != null) ? true : false;

        }

       /// <summary>
       /// Add User
       /// </summary>
       /// <param name="userDetail"></param>
       /// <returns></returns>
        public int Add(UserDetail userDetail)
        {
            var userExist = _context.User.Any(x => x.UserId == userDetail.UserId);

            if (userExist)
            {
                return 0;
            }

            var user = new User()
            {
                UserId = userDetail.UserId,
                Password = userDetail.Password,
                FirstName = userDetail.FirstName,
                LastName = userDetail.LastName,
                MobileNumber = userDetail.MobileNumber,
                CreatedDate = DateTime.UtcNow
            };

            _context.User.Add(user);
            return _context.SaveChanges();
        }
    }
}


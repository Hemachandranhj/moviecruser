﻿namespace AuthenticationServer.API
{
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using AuthenticationServer.API.Data.Context;
    using AuthenticationServer.API.Data.Repository;
    using AuthenticationServer.API.Services;
    using Swashbuckle.AspNetCore.Swagger;
    using System;
    using Microsoft.EntityFrameworkCore;

    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy", builder => builder.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());
            });            

            services.AddMvc();

            // Connection string
            string connectionString = Environment.GetEnvironmentVariable("SQLSERVER");
            if (string.IsNullOrEmpty(connectionString))
            {
                connectionString = Configuration.GetConnectionString("AuthServer");
            }

            services.AddDbContext<UserDbContext>(options => options.UseSqlServer(connectionString));
            services.AddScoped<IUserDbContext, UserDbContext>();
            services.AddScoped<IUserRepository, UserRepository>();
            services.AddScoped<IUserService, UserService>();
            services.AddScoped<ITokenGenerator, TokenGenerator>();

            services.AddSwaggerGen(swagger =>
            {
                swagger.SwaggerDoc("v1.0", new Info { Title = "Movie Cruiser Authentication", Version = "v1.0", Description = "Movie Cruiser User Authentication" });
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseSwagger();

            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1.0/swagger.json", "Authentication Server V1.0");
            });

            app.UseCors("CorsPolicy");

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "api/{controller}/{action}/{id?}");
            });
        }
    }
}

﻿namespace AuthenticationServer.API.Controllers
{
    using System;
    using AuthenticationServer.API.Models;
    using AuthenticationServer.API.Services;
    using Microsoft.AspNetCore.Mvc;    
   
    [Route("api/Authentication")]
    public class AuthenticationController : Controller
    {
        private readonly IUserService userService;
        private readonly ITokenGenerator tokenGenerator;

        public AuthenticationController(IUserService userService, ITokenGenerator tokenGenerator)
        {
            this.userService = userService;
            this.tokenGenerator = tokenGenerator;
        }      
        
        /// <summary>
        /// User Login
        /// </summary>
        /// <param name="userDetail"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("login")]
        public IActionResult UserLogin([FromBody]UserDetail userDetail)
        {
            try
            {
                var response = this.userService.LoginByUser(userDetail.UserId, userDetail.Password);
                if (!response)
                {
                    return NotFound("Please enter valid user credentials.");
                }
                string token = this.tokenGenerator.GetJWTToken(userDetail.UserId);
                return Ok(token);
            }
            catch (Exception)
            {
                return StatusCode(500, "Server error occured.");
            }
        }

        /// <summary>
        /// User Registration
        /// </summary>
        /// <param name="userDetail"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("Register")]
        public IActionResult UserRegistration([FromBody]UserDetail userDetail)
        {
            try
            {
                var response = this.userService.Add(userDetail);
                if (response == 0)
                {
                    return StatusCode(409, "User Already Exist.");
                }
                return StatusCode(201);
            }
            catch (Exception)
            {
                return StatusCode(500, "Server error occured.");
            }
        }
    }
}
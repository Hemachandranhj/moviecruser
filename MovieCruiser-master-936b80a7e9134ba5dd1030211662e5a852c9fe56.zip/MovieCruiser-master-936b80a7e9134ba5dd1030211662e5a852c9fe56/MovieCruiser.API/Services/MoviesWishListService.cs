﻿namespace MovieCruiser.API.Services
{
    using MovieCruiser.API.Data.Repository;
    using MovieCruiser.API.Models;
    using System.Collections.Generic;

    public class MoviesWishListService: IMoviesWishListService
    {
        private readonly IMoviesWishListRepository _repository;

        public MoviesWishListService(IMoviesWishListRepository repository)
        {
            _repository = repository;
        }

        /// <summary>
        /// Get all movies wish list.
        /// </summary>
        /// <returns></returns>
        public IList<MoviesWishListDetails> GetAll()
        {
            return _repository.GetAll();
        }

        /// <summary>
        /// Get a movie wish list detail.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public MoviesWishListDetails GetById(int id)
        {
            return _repository.GetById(id);
        }

        /// <summary>
        /// Add a new movie wish list.
        /// </summary>
        /// <param name="WishList"></param>
        /// <returns></returns>
        public int Add(MoviesWishListDetails WishList)
        {
            return _repository.Add(WishList);
        }

        /// <summary>
        /// Update the movie wish list detail.
        /// </summary>
        /// <param name="WishList"></param>
        /// <returns></returns>
        public int Update(MoviesWishListDetails WishList)
        {
            return _repository.Update(WishList);
        }

        /// <summary>
        /// Delete a movie wish list.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool Delete(int id)
        {
            return _repository.Delete(id);
        }
    }
}

﻿namespace MovieCruiser.API.Services
{
    using System.Collections.Generic;
    using MovieCruiser.API.Models;

    public interface IMoviesWishListService
    {
        IList<MoviesWishListDetails> GetAll();
        MoviesWishListDetails GetById(int id);
        int Add(MoviesWishListDetails WishList);
        int Update(MoviesWishListDetails WishList);
        bool Delete(int id);
    }
}

﻿namespace MovieCruiser.API.Controllers
{
    using System;
    using System.Collections.Generic;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using MovieCruiser.API.Models;
    using MovieCruiser.API.Services;

    [Route("api/MoviesWishList")]
    [Authorize]
    public class MoviesWishListController : ControllerBase
    {
        private readonly IMoviesWishListService _service;

        /// <summary>
        /// constructor for movies wish list.
        /// </summary>
        /// <param name="service"></param>
        public MoviesWishListController(IMoviesWishListService service)
        {
            this._service = service;
        }

        /// <summary>
        /// Get all movies wish list. 
        /// </summary>
        /// <returns></returns>
        // GET: api/MoviesWishList
        [HttpGet]
        public IEnumerable<MoviesWishListDetails> Get()
        {
            return _service.GetAll();
        }

        /// <summary>
        ///  Get a movie wish list detail.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: api/MoviesWishList/5
        [HttpGet("{id}")]
        public IActionResult Get([FromRoute] int id)
        {
            try
            {
                var movieWishList = this._service.GetById(id);

                if(movieWishList != null)
                {
                    return Ok(movieWishList);
                }

                return NotFound();
            }
            catch (Exception)
            {
                return StatusCode(500, "Server error occured.");
            }
        }

        /// <summary>
        /// Add a new movie wish list.
        /// </summary>
        /// <param name="moviesWishListDetails"></param>
        /// <returns></returns>
        // POST: api/MoviesWishList
        [HttpPost]
        public IActionResult Post([FromBody] MoviesWishListDetails moviesWishListDetails)
        {
            try
            {
                var response = this._service.Add(moviesWishListDetails);

                if (response > 0)
                {
                    return StatusCode(201, response);
                }

                return StatusCode(409, "Movie already added in your wishList");
            }
            catch (Exception)
            {
                return StatusCode(500, "Server error occured.");
            }
        }

        /// <summary>
        /// Update the movie wish list detail.
        /// </summary>
        /// <param name="moviesWishListDetails"></param>
        /// <returns></returns>
        // PUT: api/MoviesWishList/5
        [HttpPut]
        public IActionResult Put([FromBody] MoviesWishListDetails moviesWishListDetails)
        {
            try
            {
                var response = this._service.Update(moviesWishListDetails);

                if(response > 0)
                {
                    return Ok(response);
                }

                return NotFound();

            }
            catch (Exception)
            {
                return StatusCode(500, "Server error occured.");
            }

        }

        /// <summary>
        /// Delete a movie wish list.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                var response = this._service.Delete(id);

                if(response)
                {
                    return Ok(response);
                }

                return NotFound();
            }
            catch (Exception)
            {
                return StatusCode(500, "Server error occured.");
            }
        }
    }
}

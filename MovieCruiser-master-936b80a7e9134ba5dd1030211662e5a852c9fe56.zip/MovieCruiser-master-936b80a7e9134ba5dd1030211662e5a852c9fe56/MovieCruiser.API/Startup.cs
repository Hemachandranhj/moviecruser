﻿namespace MovieCruiser.API
{
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using MovieCruiser.API.Data.Context;
    using MovieCruiser.API.Data.Repository;
    using MovieCruiser.API.Services;
    using Swashbuckle.AspNetCore.Swagger;
    using System;

    public partial class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }
        
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy", builder => builder.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());
            });

            // JWT
            ConfigureJwtAuthService(Configuration, services);

            services.AddMvc();

            // Connection string
            string connectionString = Environment.GetEnvironmentVariable("SQLSERVER");
            if (string.IsNullOrEmpty(connectionString))
            {
                connectionString = Configuration.GetConnectionString("MCConnectionString");
            }

            services.AddDbContext<MovieCruiserDbContext>(options => options.UseSqlServer(connectionString));
            services.AddScoped<IMovieCruiserDbContext, MovieCruiserDbContext>();
            services.AddScoped<IMoviesWishListRepository, MoviesWishListRepository>();
            services.AddScoped<IMoviesWishListService, MoviesWishListService>();

            services.AddSwaggerGen(swagger =>
            {
                swagger.SwaggerDoc("v1.0", new Info { Title = "Movie Cruiser", Version = "v1.0", Description = "Movie Cruiser Wish list" });
            });
        }
        
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1.0/swagger.json", "Movie Cruiser V1.0");
            });

            app.UseCors("CorsPolicy");

            app.UseAuthentication();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "api/{controller}/{action}/{id?}");
            });
        }
    }
}

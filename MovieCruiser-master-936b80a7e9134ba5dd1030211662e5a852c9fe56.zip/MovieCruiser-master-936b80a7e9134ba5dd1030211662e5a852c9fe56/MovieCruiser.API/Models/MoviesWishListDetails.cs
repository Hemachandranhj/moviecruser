﻿namespace MovieCruiser.API.Models
{
    using Newtonsoft.Json;
    using System;

    public class MoviesWishListDetails
    {   
        [JsonProperty(PropertyName = "WatchListId")]
        public int Id { get; set; }

        [JsonProperty(PropertyName = "MovieId")]
        public int MovieId { get; set; }

        [JsonProperty(PropertyName = "Title")]
        public string MovieName { get; set; }

        [JsonProperty(PropertyName = "Overview")]
        public string Overview { get; set; }

        [JsonProperty(PropertyName = "PosterPath")]
        public string PosterPath { get; set; }

        [JsonProperty(PropertyName = "VoteCount")]
        public int VoteCount { get; set; }

        [JsonProperty(PropertyName = "VoteAverage")]
        public decimal VoteAverage { get; set; }

        [JsonProperty(PropertyName ="Comments")]
        public string Comments { get; set; }

        [JsonProperty(PropertyName = "ReleaseDate")]
        public DateTime? ReleaseDate { get; set; }
    }
}

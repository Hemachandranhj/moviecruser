﻿namespace MovieCruiser.API.Data.Repository
{
    using System.Linq;
    using System.Collections.Generic;
    using MovieCruiser.API.Data.Context;
    using MovieCruiser.API.Models;
    using MovieCruiser.API.Data.Entities;

    public class MoviesWishListRepository: IMoviesWishListRepository
    {
        private readonly IMovieCruiserDbContext _context;

        public MoviesWishListRepository(IMovieCruiserDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Get all movies wish list.
        /// </summary>
        /// <returns></returns>
        public IList<MoviesWishListDetails> GetAll()
        {
            return _context.MoviesWishList.Select(wishList => new MoviesWishListDetails
            {
                Id = wishList.Id,
                MovieId = wishList.MovieId,
                MovieName = wishList.MovieName,
                Overview = wishList.Overview,
                PosterPath =wishList.PosterPath,
                VoteCount = wishList.VoteCount,
                VoteAverage = wishList.VoteAverage,
                Comments = wishList.Comments,
                ReleaseDate = wishList.ReleaseDate
            }).ToList();
        }

        /// <summary>
        /// Get a movie wish list detail.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public MoviesWishListDetails GetById(int id)
        {
            var response = _context.MoviesWishList.SingleOrDefault(x => x.Id == id);

            if(response == null)
            {
                return null;
            }

            return new MoviesWishListDetails {
                Id = response.Id,
                MovieId = response.MovieId,
                MovieName = response.MovieName,
                Overview = response.Overview,
                PosterPath = response.PosterPath,
                VoteCount = response.VoteCount,
                VoteAverage = response.VoteAverage,
                Comments = response.Comments,
                ReleaseDate = response.ReleaseDate
            };
        }

        /// <summary>
        /// Add a new movie wish list.
        /// </summary>
        /// <param name="WishList"></param>
        /// <returns></returns>
        public int Add(MoviesWishListDetails WishList)
        {
            var movieWishList = _context.MoviesWishList.SingleOrDefault(x => x.MovieId == WishList.MovieId);

            if (movieWishList != null)
            {
                return 0;
            }

            var wishList = new MoviesWishList()
            {               
                MovieId = WishList.MovieId,
                MovieName = WishList.MovieName,
                Overview = WishList.Overview,
                PosterPath = WishList.PosterPath,
                VoteCount = WishList.VoteCount,
                VoteAverage = WishList.VoteAverage,
                Comments = WishList.Comments,
                ReleaseDate = WishList.ReleaseDate
            };

            _context.MoviesWishList.Add(wishList);
            return _context.SaveChanges();
        }

        /// <summary>
        /// Update the movie wish list detail.
        /// </summary>
        /// <param name="WishList"></param>
        /// <returns></returns>
        public int Update(MoviesWishListDetails WishList)
        {
            var MovieWishList = _context.MoviesWishList.SingleOrDefault(x => x.Id == WishList.Id);

            if(MovieWishList != null)
            {
                MovieWishList.MovieId = WishList.MovieId;
                MovieWishList.MovieName = WishList.MovieName;
                MovieWishList.Overview = WishList.Overview;
                MovieWishList.PosterPath = WishList.PosterPath;
                MovieWishList.VoteCount = WishList.VoteCount;
                MovieWishList.VoteAverage = WishList.VoteAverage;
                MovieWishList.Comments = WishList.Comments;
                MovieWishList.ReleaseDate = WishList.ReleaseDate;
                return _context.SaveChanges();
            }
            return 0;
        }

        /// <summary>
        /// Delete a movie wish list.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool Delete(int id)
        {
            var wishList = _context.MoviesWishList.Find(id);

            if(wishList != null)
            {
                _context.MoviesWishList.Remove(wishList);
                _context.SaveChanges();
                return true;
            }

            return false;
        }


    }
}


﻿namespace MovieCruiser.API.Data.Repository
{
    using System.Collections.Generic;
    using MovieCruiser.API.Models;

    public interface IMoviesWishListRepository
    {
        IList<MoviesWishListDetails> GetAll();
        MoviesWishListDetails GetById(int id);
        int Add(MoviesWishListDetails WishList);
        int Update(MoviesWishListDetails WishList);
        bool Delete(int id);
    }
}

﻿namespace MovieCruiser.API.Data.Entities
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    public class MoviesWishList
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        
        public int MovieId { get; set; }
        
        public string MovieName { get; set; }
        
        public string Overview { get; set; }
       
        public string PosterPath { get; set; }
        
        public int VoteCount { get; set; }
       
        public decimal VoteAverage { get; set; }
       
        public string Comments { get; set; }

        public DateTime? ReleaseDate { get; set; }
    }
}

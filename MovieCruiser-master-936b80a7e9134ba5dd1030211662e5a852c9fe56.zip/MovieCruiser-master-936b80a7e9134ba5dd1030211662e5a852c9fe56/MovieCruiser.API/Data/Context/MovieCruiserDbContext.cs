﻿namespace MovieCruiser.API.Data.Context
{
    using Microsoft.EntityFrameworkCore;
    using MovieCruiser.API.Data.Entities;

    public class MovieCruiserDbContext : DbContext, IMovieCruiserDbContext
    {
        public MovieCruiserDbContext() { }

        public MovieCruiserDbContext(DbContextOptions<MovieCruiserDbContext> contextOptions): base(contextOptions)
        {
            Database.EnsureCreated();
        }

        public DbSet<MoviesWishList> MoviesWishList { get; set; }
    }
}

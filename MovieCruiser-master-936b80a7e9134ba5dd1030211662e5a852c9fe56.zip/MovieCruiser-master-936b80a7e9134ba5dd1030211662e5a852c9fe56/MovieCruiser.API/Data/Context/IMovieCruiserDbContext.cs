﻿namespace MovieCruiser.API.Data.Context
{
    using Microsoft.EntityFrameworkCore;
    using MovieCruiser.API.Data.Entities;

    public interface IMovieCruiserDbContext
    {
        DbSet<MoviesWishList> MoviesWishList { get; set; }

        int SaveChanges();
    }
}

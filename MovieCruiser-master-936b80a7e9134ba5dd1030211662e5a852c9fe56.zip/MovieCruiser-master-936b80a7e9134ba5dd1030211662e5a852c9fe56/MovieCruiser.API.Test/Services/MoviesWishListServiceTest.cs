﻿namespace MovieCruiser.API.Test.Services
{
    using Microsoft.AspNetCore.Mvc;
    using Moq;
    using MovieCruiser.API.Models;
    using MovieCruiser.API.Data.Repository;
    using System;
    using System.Collections.Generic;
    using Xunit;
    using MovieCruiser.API.Services;

    public class MoviesWishListServiceTest
    {
        [Fact]
        public void GetAllMethod_ShouldReturnMoviesWishListAsExpected()
        {
            // Arrange
            var mockRepository = new Mock<IMoviesWishListRepository>();
            mockRepository.Setup(s => s.GetAll()).Returns(this.GetMoviesWishList());
            var service = new MoviesWishListService(mockRepository.Object);

            // Act
            var result = service.GetAll() as List<MoviesWishListDetails>;

            // Assert
            Assert.Equal(2, result.Count);
        }

        [Fact]
        public void GetMethod_ShouldReturnMoviesWishListAsExpected()
        {
            // Arrange
            var expectedResponse = this.GetMoviesWishList()[0];
            var mockRepository = new Mock<IMoviesWishListRepository>();
            mockRepository.Setup(s => s.GetById(It.IsAny<int>())).Returns(expectedResponse);
            var service = new MoviesWishListService(mockRepository.Object);

            // Act
            var result = service.GetById(1);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(expectedResponse.Id, result.Id);
            Assert.Equal(expectedResponse.MovieId, result.MovieId);
            Assert.Equal(expectedResponse.MovieName, result.MovieName);
            Assert.Equal(expectedResponse.Overview, result.Overview);
            Assert.Equal(expectedResponse.PosterPath, result.PosterPath);
            Assert.Equal(expectedResponse.VoteCount, result.VoteCount);
            Assert.Equal(expectedResponse.VoteAverage, result.VoteAverage);
            Assert.Equal(expectedResponse.Comments, result.Comments);
        }

        [Fact]
        public void PostMethod_ShouldAddMoviesWishListAsExpected()
        {
            // Arrange
            var moviesWishList = new MoviesWishListDetails()
            {
                MovieId = 5,
                MovieName = "Kaala",
                Overview = "Test",
                PosterPath = "Testtt",
                VoteCount = 55,
                VoteAverage = 5.5M,
                Comments = "Nice Tamil Movie",
                ReleaseDate = DateTime.Now
            };
            var mockRepository = new Mock<IMoviesWishListRepository>();
            mockRepository.Setup(s => s.Add(It.IsAny<MoviesWishListDetails>())).Returns(1);
            var service = new MoviesWishListService(mockRepository.Object);

            // Act
            var result = service.Add(moviesWishList);

            // Assert
            Assert.Equal(1, result);
        }

        [Fact]
        public void PutMethod_ShouldUpdateMoviesWishListAsExpected()
        {
            // Arrange
            var updateMoviesWishList = new MoviesWishListDetails()
            {
                Id = 1,
                MovieId = 5,
                MovieName = "Tamil Padam",
                Overview = "TestOverview",
                PosterPath = "Test",
                VoteCount = 555,
                VoteAverage = 8.5M,
                Comments = "Cool..nice Film",
                ReleaseDate = DateTime.Now
            };
            var mockRepository = new Mock<IMoviesWishListRepository>();
            mockRepository.Setup(s => s.Update(It.IsAny<MoviesWishListDetails>())).Returns(1);
            var service = new MoviesWishListService(mockRepository.Object);

            // Act
            var result = service.Update(updateMoviesWishList);

            // Assert
            Assert.Equal(1, result);
        }

        [Fact]
        public void DeleteMethod_ShouldRemoveMoviesWishListAsExpected()
        {
            // Arrange            
            var mockRepository = new Mock<IMoviesWishListRepository>();
            mockRepository.Setup(s => s.Delete(It.IsAny<int>())).Returns(true);
            var service = new MoviesWishListService(mockRepository.Object);

            // Act
            var result = service.Delete(1);

            // Assert

            Assert.True(result);
        }

        private List<MoviesWishListDetails> GetMoviesWishList()
        {
            List<MoviesWishListDetails> moviesWishList = new List<MoviesWishListDetails>
            {
                new MoviesWishListDetails{
                    Id=1,
                    MovieId= 1,
                    MovieName= "Fantastic Five",
                    Overview= "Test test",
                    PosterPath= "Testtt",
                    VoteCount= 55,
                    VoteAverage= 5.5M,
                    Comments= "Nice Movie",
                    ReleaseDate= DateTime.Now
                },

                new MoviesWishListDetails{
                    Id=2,
                    MovieId= 2,
                    MovieName= "Jurasic World",
                    Overview= "Test test",
                    PosterPath= "Testtt",
                    VoteCount= 100,
                    VoteAverage= 7.5M,
                    Comments= "Thriler Movie",
                    ReleaseDate= DateTime.Now
                }
            };

            return moviesWishList;
        }
    }
}

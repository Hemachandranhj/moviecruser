﻿namespace MovieCruiser.API.Test.Data
{
    using Microsoft.EntityFrameworkCore;
    using MovieCruiser.API.Data.Context;
    using MovieCruiser.API.Data.Entities;
    using MovieCruiser.API.Models;
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class DatabaseFixture : IDisposable
    {
        public IMovieCruiserDbContext dbContext;

        public DatabaseFixture()
        {
            var dbContextOptions = new DbContextOptionsBuilder<MovieCruiserDbContext>().UseInMemoryDatabase(databaseName: "MovieCruiser").Options;
            dbContext = new MovieCruiserDbContext(dbContextOptions);

            dbContext.MoviesWishList.Add(new MoviesWishList
            {
                Id = 105,
                MovieId = 1,
                MovieName = "Fantastic Five",
                Overview = "Test test",
                PosterPath = "Testtt",
                VoteCount = 55,
                VoteAverage = 5.5M,
                Comments = "Nice Movie",
                ReleaseDate = DateTime.Now
            });

            dbContext.MoviesWishList.Add(new MoviesWishList
            {
                Id = 106,
                MovieId = 2,
                MovieName = "Faffntastic Five",
                Overview = "Test test",
                PosterPath = "Testtt",
                VoteCount = 55,
                VoteAverage = 5.5M,
                Comments = "Nice Movie",
                ReleaseDate = DateTime.Now
            });

            dbContext.SaveChanges();
        }

        public void Dispose()
        {           
            dbContext = null;
        }
    }
}

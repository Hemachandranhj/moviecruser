﻿namespace MovieCruiser.API.Test.Data
{
    using MovieCruiser.API.Models;
    using MovieCruiser.API.Data.Repository;
    using System;
    using Xunit;
    using System.Linq;

    public class MoviesWishListRepositoryTest: IClassFixture<DatabaseFixture>
    {
        private readonly DatabaseFixture _fixture;
        private readonly IMoviesWishListRepository _repository;

        public MoviesWishListRepositoryTest(DatabaseFixture fixture)
        {
            this._fixture = fixture;
            this._repository = new MoviesWishListRepository(this._fixture.dbContext);
        }

        [Fact]
        public void GetAllMethod_ShouldReturnMoviesWishListAsExpected()
        {
            // Act
            var wishList = this._repository.GetAll();
            var expectedResult = this._fixture.dbContext.MoviesWishList;

            // Assert
            Assert.Equal(expectedResult.Count(), wishList.Count());
           
        }

        [Fact]
        public void GetMethod_ShouldReturnMoviesWishListAsExpected()
        {
            // Act
            var wishList = this._repository.GetById(106);

            // Assert
            Assert.Equal(106, wishList.Id);
        }

        [Fact]
        public void PostMethod_ShouldAddMoviesWishListAsExpected()
        {
            // Arrange
            var expected = this._fixture.dbContext.MoviesWishList.Count() + 1;
            var wishList = new MoviesWishListDetails
            {
                MovieId = 555,
                MovieName = "Fantastic Four",
                Overview = "Test",
                PosterPath = "Tett",
                VoteCount = 505,
                VoteAverage = 7.5M,
                Comments = "Nice Movie..",
                ReleaseDate = DateTime.Now
            };

            // Act
            this._repository.Add(wishList);

            // Assert
            Assert.Equal(expected, this._fixture.dbContext.MoviesWishList.Count());
        }

        [Fact]
        public void PutMethod_ShouldUpdateMoviesWishListAsExpected()
        {
            // Arrange
            var wishList = new MoviesWishListDetails
            {
                Id = 105,
                MovieId = 10,
                MovieName = "Fantastic Six",
                Overview = "Test",
                PosterPath = "Tett",
                VoteCount = 55,
                VoteAverage = 5.5M,
                Comments = "Nice Movie",
                ReleaseDate = DateTime.Now
            };

            // Act
            var actual = this._repository.Update(wishList);

            // Assert
            Assert.Equal(1, actual);
        }

        [Fact]
        public void DeleteMethod_ShouldRemoveMoviesWishListAsExpected()
        {          

            // Act
            var actual = this._repository.Delete(106);

            // Assert
            Assert.True((bool)actual);

        }
    }
}

import { CommonPage } from './common.po';
import { protractor } from 'protractor/built/ptor';
import { browser } from 'protractor';

describe('Register', () => {

    it('should redirect to register page from login page', () => {   
        CommonPage.navigateToLogin();    
        CommonPage.buttonClick('lnkRegister').then(() => {
            expect(CommonPage.getText('title')).toEqual('User Registration');
        });
    });

    it('register with the valid details and navigate to login', () => {

        CommonPage.navigateToLogin();
        CommonPage.buttonClick('lnkRegister');
        expect(CommonPage.getText('title')).toEqual('User Registration');
        const userId = new Date().valueOf();
        CommonPage.sendKeys('userId', userId.toString());
        CommonPage.sendKeys('password', 'pass234');
        CommonPage.sendKeys('firstName', 'suresh');
        CommonPage.sendKeys('lastName', 'r');
        CommonPage.sendKeys('mobNumber', '987564589');
       
        CommonPage.buttonClick('btnRegister').then(() => {
             browser.wait(protractor.ExpectedConditions.alertIsPresent(), 1000);
             browser.switchTo().alert().accept().then(() => {
                expect(CommonPage.getText('title')).toEqual('Login');
            });
        });
    });
});
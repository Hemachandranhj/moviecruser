import { CommonPage } from './common.po';

describe('Movie List', () => {

    const userName = "444318";
    const password = "pass123";

    beforeEach(() => {
        CommonPage.navigateToLogin();
        CommonPage.sendKeys('username', userName);
        CommonPage.sendKeys('password', password);
        CommonPage.buttonClick('btnLogin').then(() => {
            expect(CommonPage.getText('title')).toEqual('Popular Movies');
        });
    });

    it('should navigate to popular movies', () => {
        expect(CommonPage.getText('title')).toEqual('Popular Movies');
    });

    it('should display movie details', () => {
        CommonPage.clickMovie().then(() => {
            expect(CommonPage.getText('title')).not.toBeNull();           
            expect(CommonPage.getText('btnWishList')).toEqual('Add to WishList');
            expect(CommonPage.getText('recomentedMovies')).toEqual('Recommended Movies');
            expect(CommonPage.getText('overview')).not.toBeNull();
            expect(CommonPage.getText('movieLikes')).not.toBeNull();
            expect(CommonPage.getText('contentWarning')).not.toBeNull();            
        });
    });
});
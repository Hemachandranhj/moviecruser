import { CommonPage } from './common.po';
import { element, by } from '../../node_modules/protractor';

describe('Wish List', () => {

    const userName = "444318";
    const password = "pass123";

    beforeEach(() => {
        CommonPage.navigateToLogin();
        CommonPage.sendKeys('username', userName);
        CommonPage.sendKeys('password', password);
        CommonPage.buttonClick('btnLogin').then(() => {
            expect(CommonPage.getText('title')).toEqual('Popular Movies');
        });
    });

    it('add movie to the wishList', () => {
        CommonPage.clickMovie().then(() => {
            CommonPage.waitPresenceOfElement(element(by.id('comments'))).then(() => {
                CommonPage.sendKeys('comments', 'Nice Movie!!!');
                CommonPage.buttonClick('btnWishList').then(() => {
                    CommonPage.waitForAlert();
                    CommonPage.acceptAlert().then(() => {
                        expect(CommonPage.getText('title')).toEqual('My WishList');
                    });
                });
            });
        });
    });    

    it('update the comments', () => {
        CommonPage.buttonClick('myWishlist').then(() => {
            CommonPage.waitPresenceOfElement(element(by.id('comments'))).then(() => {
                CommonPage.sendKeys('comments', 'Nice Movie');
                CommonPage.buttonClick('btnSave').then(() => {
                    CommonPage.waitForAlert();
                    CommonPage.acceptAlert().then(() => {
                        expect(CommonPage.getText('title')).toEqual('My WishList');
                    });
                });
            });
        });
    });

    it('should delete the  movie from wishList page', () => {
        CommonPage.buttonClick('myWishlist').then(() => {
            CommonPage.buttonClick('btnDelete').then(() => {
                CommonPage.waitForAlert();
                CommonPage.acceptAlert().then(() => {
                    expect(CommonPage.getText('title')).toEqual('My WishList');
                });
            });
        });
    });
});
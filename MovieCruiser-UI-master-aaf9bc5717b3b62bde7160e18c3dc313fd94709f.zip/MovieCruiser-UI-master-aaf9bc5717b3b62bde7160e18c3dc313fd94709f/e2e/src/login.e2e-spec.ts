import { CommonPage } from './common.po';

describe('Login', () => {

    const userName = "444318";
    const password = "pass123";

    beforeEach(() => {
        CommonPage.navigateToLogin();
    });

    it('should logged in and display the popular movies page', () => {
        expect(CommonPage.getText('title')).toEqual('Login');
        CommonPage.sendKeys('username', userName);
        CommonPage.sendKeys('password', password);
        CommonPage.buttonClick('btnLogin').then(() => {
            expect(CommonPage.getText('title')).toEqual('Popular Movies');
        });
    });

    it('should not logged in and display the error message', () => {
        CommonPage.sendKeys('username', userName);
        CommonPage.sendKeys('password', "password");
        CommonPage.buttonClick('btnLogin').then(() => {
            expect(CommonPage.getText('error')).toEqual('UserName or Password incorrect');
        });
    });

    it('should redirect to register page', () => {       
        CommonPage.buttonClick('lnkRegister').then(() => {
            expect(CommonPage.getText('title')).toEqual('User Registration');
        });
    });
});
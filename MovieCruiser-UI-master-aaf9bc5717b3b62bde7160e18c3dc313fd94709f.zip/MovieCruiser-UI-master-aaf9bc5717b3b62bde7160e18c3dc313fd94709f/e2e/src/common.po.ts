import { browser, by, element, promise, protractor, ElementFinder } from 'protractor';

export class CommonPage {

    static buttonClick(id: string): promise.Promise<any> {
        return element(by.id(id)).click();
    }

    static getText(id: string): promise.Promise<any> {
        return element(by.id(id)).getText();
    }

    static navigateToLogin() {
        return browser.get('/login');
    }

    static navigateToWatchlist() {
        return browser.get('/wishlist');
    }

    static sendKeys(id: string, values: string) {
        element(by.id(id)).clear().then(() => {
            element(by.id(id)).sendKeys(values);
        });
    }

    static waitForAlert(): void {
        browser.wait(protractor.ExpectedConditions.alertIsPresent(), 1000);
    }

    static acceptAlert(): promise.Promise<any> {
        return browser.switchTo().alert().accept();
    }
    
    static clickMovie(): promise.Promise<any> {
        return element(by.css('.card-img-top')).click();
    }

    static waitPresenceOfElement(elementToWaitFor: ElementFinder): promise.Promise<any> {
        return browser.wait(() => {
            return elementToWaitFor.isPresent();
        })
    }

}
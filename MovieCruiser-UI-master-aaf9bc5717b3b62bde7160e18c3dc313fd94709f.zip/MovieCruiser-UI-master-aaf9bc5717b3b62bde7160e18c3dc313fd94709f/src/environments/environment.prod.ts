export const environment = {
  production: true,
  authenticationServerUrl: 'http://localhost:49874/api/Authentication/',
  moviesWishListUrl: 'http://localhost:49873/api/MoviesWishList',
  tmDbUrl: 'https://api.themoviedb.org/3/',
  apiKey:  "9a96f9a426e1298eb043fe58315624d4"
};

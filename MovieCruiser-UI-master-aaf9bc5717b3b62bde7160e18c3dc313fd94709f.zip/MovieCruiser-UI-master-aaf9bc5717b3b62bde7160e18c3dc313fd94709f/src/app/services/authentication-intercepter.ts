import { Injectable } from '@angular/core';
import {
    HttpRequest,
    HttpHandler,
    HttpEvent,
    HttpInterceptor
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthenticationService } from "./authentication.service";
import { Routes } from "../app-routes";

@Injectable()
export class AuthInterceptor implements HttpInterceptor {

    constructor(public authService: AuthenticationService) { }
    // interceptor for handling the http request
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        let headers = request.headers.set('Content-Type', 'application/json');      
        if (request.url.toLowerCase().indexOf('movieswishlist') > 0) {
            headers = headers.set('Authorization', `Bearer ${this.authService.getToken()}`).set('userId', this.authService.getUserId());
        }
        request = request.clone({
            headers: headers
        });

        return next.handle(request);
    }
}
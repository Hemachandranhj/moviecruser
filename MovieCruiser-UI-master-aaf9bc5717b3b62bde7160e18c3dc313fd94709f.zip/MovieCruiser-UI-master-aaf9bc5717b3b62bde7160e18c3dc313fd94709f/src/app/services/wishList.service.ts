import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { map, catchError } from "rxjs/operators";
import { Observable, of } from "rxjs"
// // import { IMovieDetails } from "../models/movie-details.interface";
import { MovieDetails } from "../models/movie-details";
import { environment } from "../../environments/environment.prod";

@Injectable()
export class WishListService {

    apiUrl = environment.moviesWishListUrl;
    httpOptions = {
        headers: new HttpHeaders({
            'Content-Type': 'application/json'
        })
    };

    constructor(private http: HttpClient) { }

    // method for getting wish list movies
    getWishList(): any {
        return this.http.get(this.apiUrl).pipe(map((response: any) => {
            return this.mapWishLists(response);
        }),
            catchError((error: any): any => {
                return error;
            }));
    }

    // method for adding a movie in wishlist
    post(movieDetails: MovieDetails): Observable<any> {
        var body = JSON.stringify(movieDetails);
        return this.http.post(this.apiUrl, body, this.httpOptions).pipe(map((response: any) => {
            return "Movie Added Successfully in WishList";
        }),
            catchError((error: any): any => {
                if (error.status == 409) {
                    return of("Movie Already Exist in WishList");
                }
                throw error.error;
            }));

    }

    // method to update the movie in wish list
    put(movieDetails: MovieDetails): Observable<any> {
        var body = JSON.stringify(movieDetails);
        return this.http.put(this.apiUrl, body, this.httpOptions).pipe(map((response: any): any => {
            if (response.status === 404) {
                return of("Movie update failed");
            }
            return "Movie updated successfully"
        }),
            catchError((error: any): any => {
                throw error.error;
            }));

    }

    // method to delete the movie in wish list
    deleteWishList(id: number): Observable<boolean> {
        var url = this.apiUrl + "/" + id;
        return this.http.delete(url).pipe(map((response: any): any => {
            if (response == true) {
                return "Movie deleted in wish list successfully.";
            }
            return "Failed to delete a movie in wish list.";
        }),
            catchError((error: any): any => {
                throw error.error;
            }));
    }

    // method to map the wish list results
    private mapWishLists(response: any): MovieDetails[] {
        const movieDetails = [];
        response.forEach(item => {
            movieDetails.push(this.mapWishListDetails(item));
        });
        return movieDetails;
    }

    // method to map the movie wish list
    private mapWishListDetails(data: any): MovieDetails {
        var wishListDetails = new MovieDetails();
        wishListDetails.movieId = data.MovieId;
        wishListDetails.comments = data.Comments;
        wishListDetails.watchListId = data.WatchListId;
        wishListDetails.overview = data.Overview;
        wishListDetails.voteAverage = data.VoteAverage;
        wishListDetails.voteCount = data.VoteCount;
        wishListDetails.posterPath = data.PosterPath;
        wishListDetails.releaseDate = data.ReleaseDate;
        wishListDetails.title = data.Title;
        return wishListDetails;
    }
}

import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { map } from "rxjs/operators";
import { Observable } from "rxjs";
import { IMovieDetails } from "../models/movie-details.interface";
import { MovieDetails } from "../models/movie-details";
import { MovieResults } from "../models/movie-results";
import { environment } from "../../environments/environment.prod";

@Injectable()
export class MovieService {

    apiKey: string;
    apiBaseUrl: string;

    constructor(private http: HttpClient) {
        this.apiKey = environment.apiKey;
        this.apiBaseUrl = environment.tmDbUrl;
    }

    // method for getting movies list
    get(): Observable<MovieResults> {
        var url = this.apiBaseUrl + "movie/popular?page=1&language=en-US&api_key=" + this.apiKey;
        return this.http.get(url).pipe(map((response: any) => {
            return this.mapMovieResults(response);
        }),);
    }

    // method for getting movie by id
    getById(id: number): Observable<IMovieDetails> {
        var url = this.apiBaseUrl + "movie/" + id + "?api_key=" + this.apiKey + "&language=en-US";
        return this.http.get(url).pipe(map((response: any) => {
            return this.mapMovieDetails(response);
        }));
    }

    // method for getting recommended movies
    getRecommendedMovies(id: number): Observable<MovieResults> {
        var url = this.apiBaseUrl + "movie/" + id + "/recommendations?api_key=" + this.apiKey + "&language=en-US&page=1";
        return this.http.get(url).pipe(map((response: any) => {
            return this.mapMovieResults(response);
        }));
    }

    // method for searching movie
    search(searchQuery: string): Observable<MovieResults> {
        var url = this.apiBaseUrl + "search/movie?api_key=" + this.apiKey + "&language=en-US&page=1&include_adult=false&sort_by=popularity.desc&query=" + searchQuery;
        return this.http.get(url).pipe(map((response: any) => {
            return this.mapMovieResults(response);
        }));
    }


    // method for mapping movie results
    private mapMovieResults(data: any): MovieResults {
        var movieResults = new MovieResults();
        var movieList = [];
        data.results.forEach(item => {
            movieList.push(this.mapMovieDetails(item));            
        });
        movieResults.results = movieList;
        return movieResults;
    }

    // method for mapping a movie to model
    private mapMovieDetails(details: any): IMovieDetails {
        var movieDetails = new MovieDetails();
        movieDetails.movieId = details.id;
        movieDetails.comments = details.comments;
        movieDetails.watchListId = details.watchListId;
        movieDetails.overview = details.overview;
        movieDetails.popularity = details.popularity;
        movieDetails.title = details.title;
        movieDetails.video = details.video;
        movieDetails.voteAverage = details.vote_average;
        movieDetails.voteCount = details.vote_count;
        movieDetails.adult = details.adult;
        movieDetails.backDropPath = details.backdrop_path;
        movieDetails.originalLanguage = details.original_language;
        movieDetails.originalTitle = details.original_title;
        movieDetails.posterPath = details.poster_path;
        movieDetails.releaseDate = details.release_date;

        return movieDetails;
    }
}

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";

import { AppComponent } from './app.component';
import { HeaderComponent } from "./header/header.component";
import { MoviesListComponent } from "./movies-list/movies-list.component";
import { WishListComponent } from "./wishList/wishList.component";
import { MovieDetailsComponent } from "./movie-details/movie-details.component";
import { AppRoutingModule } from "./app-routing.module";
import { MovieService } from "./services/movies.service";
import { WishListService } from "./services/wishList.service";
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './registration/registration.component';
import { AuthenticationGuard } from './services/authentication-guard.service';
import { AuthInterceptor } from './services/authentication-intercepter';
import { AuthenticationService } from './services/authentication.service';
import { HTTP_INTERCEPTORS } from '@angular/common/http';

const Components = [
  AppComponent,
  HeaderComponent,
  MoviesListComponent,
  WishListComponent,
  MovieDetailsComponent,
  LoginComponent,
  RegisterComponent
];

@NgModule({
  declarations: [    
    Components
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    AppRoutingModule
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    },
    AuthenticationGuard,
    AuthInterceptor,
    AuthenticationService,
    MovieService,
    WishListService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

export class Routes{
    static readonly popularMovies = "popularMovies";
    static readonly search = "search";
    static readonly wishList = "wishList";
    static readonly movieDetails = "movieDetails/:id";
    static readonly login = "login";
} 
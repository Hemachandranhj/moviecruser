import { TestBed } from "@angular/core/testing";
import { of } from "rxjs";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { MovieService } from "../services/movies.service";
import { MovieDetails } from "../models/movie-details";
import { MovieResults } from "../models/movie-results";
import { MoviesListComponent } from "./movies-list.component";

describe("MovieListComponent", () => {

    let movieService: MovieService;
    let componentInstance: any;
    const movieDetails: MovieDetails = {
        "movieId": 234567,
        "title": "test",
        "comments": "test",
        "voteCount": 6,
        "voteAverage": 7,
        "popularity": 6,
        "posterPath": "test/test",
        "backDropPath": "test/test",
        "adult": true,
        "overview": "good",
        "releaseDate": "22-04-1987",
        "video": "test",
        "originalTitle": "test",
        "originalLanguage": "en_US",
        "watchListId": 1
    }
    const movieResults: MovieResults = {
        results: [movieDetails]
    };
   
    const dummyActivatedRoute: any = {
        "queryParams": of({ search: "Deedpool" }),
        "snapshot": {
            "params": { "id": 20938 }
        }
    }

    beforeEach(() => {
        movieService = jasmine.createSpyObj("MovieService", ["get", "search"]);       
        ((movieService.search) as jasmine.Spy).and.returnValue(of(movieResults));
        ((movieService.get) as jasmine.Spy).and.returnValue(of(movieResults));
        componentInstance = new MoviesListComponent(movieService, dummyActivatedRoute);
    });

    it("should create a component", () => {

        TestBed.configureTestingModule({
            imports: [
                FormsModule,
                ReactiveFormsModule
            ],
            declarations: [MoviesListComponent],
            providers: [
                { provide: ActivatedRoute, useValue: dummyActivatedRoute },
                { provide: MovieService, useValue: movieService }
            ],
            schemas: [NO_ERRORS_SCHEMA]
        });

        const fixture = TestBed.createComponent(MoviesListComponent);
        const component = fixture.componentInstance;
        expect(component).toBeTruthy();
    });

    it("should call the movie service search method as expected", () => {

        // Act
        componentInstance.ngOnInit();

        // Assert
        expect(movieService.search).toHaveBeenCalled();

    });

    it("should call the movie service get method as expected", () => {

        // Arrange
        dummyActivatedRoute.queryParams = of({});

        // Act
        componentInstance.ngOnInit();

        // Assert
        expect(movieService.get).toHaveBeenCalled();
    });
});

import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { MovieResults } from "../models/movie-results";
import { MovieService } from "../services/movies.service";

@Component({
    selector: "movies-list",
    templateUrl: "./movies-list.component.html"
})

export class MoviesListComponent implements OnInit {

    movieResults: MovieResults;

    constructor(private service: MovieService,
        private route: ActivatedRoute) {
    }

    // on init to load search movies or movies list based on query params
    ngOnInit() {
        this.route.queryParams.subscribe(queryParams => {
            var searchDesc = queryParams["search"];
            if (searchDesc) {
                this.service.search(searchDesc).subscribe(response => {
                    this.movieResults = response;
                },
                    error => {
                        window.alert(error);
                    });
            }
            else {
                this.service.get().subscribe(response => {
                    this.movieResults = response;
                },
                    error => {
                        window.alert(error);
                    });
            }
        });
    }
}

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-register',
  templateUrl: './registration.component.html'
})

export class RegisterComponent implements OnInit {

  loading = false;
  submitted = false;
  registerForm: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private authService: AuthenticationService,
    private router: Router) { }

  // on init to initialize the form
  ngOnInit() {
    this.initializeForm();
  }

  // method to save the user registration
  save() {
    this.submitted = true;
    if (this.registerForm.valid) {
      this.loading = true;
      const formValues = this.registerForm.value;
      this.authService.Register(formValues).subscribe(result => {
        this.loading = false;
        window.alert(result);
        this.router.navigate(['/login']);
      },
        error => {
          this.loading = false;
        });
    }
  }

  // method to initialize the register form
  private initializeForm() {
    this.registerForm = this.formBuilder.group({
      userId: ['', Validators.required],
      mobNumber: ['', [Validators.required, Validators.minLength(9), Validators.maxLength(9)]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required]     
    });
  }
}
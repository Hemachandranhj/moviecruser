import { Router } from "@angular/router";
import { FormBuilder } from '@angular/forms';
import { of } from "rxjs";
import { RegisterComponent } from "./registration.component";
import { AuthenticationService } from "../services/authentication.service";


describe("LoginComponent", () => {
  
    let router: Router;
    let authService: AuthenticationService;
    let componentInstance: any;
    let formBuilder: FormBuilder;
  
    beforeEach(() => {
        authService = jasmine.createSpyObj("AuthenticationService", ["Register"]);

        (authService.Register as jasmine.Spy).and.returnValue(of(null));

        router = jasmine.createSpyObj("router", ["navigate"]);

        componentInstance = new RegisterComponent(formBuilder, authService, router);
    });

    it("should create a component", () => {
        // Assert
        expect(componentInstance).toBeTruthy();
    });
});

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html'
})

export class LoginComponent implements OnInit {

  loading = false;
  submitted = false;
  loginForm: FormGroup;
  error: string;

  constructor(private formBuilder: FormBuilder,
    private authService: AuthenticationService,
    private router: Router) { }

  // on init to delete token and initialize the form
  ngOnInit() {

    this.authService.deleteToken();
    this.initializeForm();

  }

  // method for logged in user
  login() {
    
    this.submitted = true;

    if (this.loginForm.valid) {

      this.loading = true;
      this.authService.login(this.loginForm.controls.username.value, this.loginForm.controls.password.value).subscribe(result => {
        if (result === 404) {
          this.error = 'UserName or Password incorrect';
          this.loading = false;
        }
        this.authService.setToken(result);
        this.authService.setUserId(this.loginForm.controls.username.value);
        this.router.navigate(['/popularMovies']);
      },
        error => {
          this.loading = false;
        });
    }
  }

  // method to initialize the form
  private initializeForm() {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }
}
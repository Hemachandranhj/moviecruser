import { RouterModule, Routes } from "@angular/router";
import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule } from "@angular/forms";
import { Routes as AppRoutes } from "./app-routes";

import { MoviesListComponent } from "./movies-list/movies-list.component";
import { WishListComponent } from "./wishList/wishList.component";
import { MovieDetailsComponent } from "./movie-details/movie-details.component";
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './registration/registration.component';
import { AuthenticationGuard } from './services/authentication-guard.service';


const routes: Routes = [
    { path: '', redirectTo: '/popularMovies', pathMatch: 'full' },
    { path: AppRoutes.popularMovies, component: MoviesListComponent, canActivate: [AuthenticationGuard]},
    { path: AppRoutes.search, component: MoviesListComponent, canActivate: [AuthenticationGuard]},
    { path: AppRoutes.wishList, component: WishListComponent, canActivate: [AuthenticationGuard]},
    { path: AppRoutes.movieDetails, component: MovieDetailsComponent, canActivate: [AuthenticationGuard]},
    { path: 'login', component: LoginComponent },
    { path: 'register', component: RegisterComponent },
    { path: "**", redirectTo: '/login', pathMatch: 'full' }
];

@NgModule({    
    imports:[BrowserModule, FormsModule, RouterModule.forRoot(routes)],
    exports: [RouterModule]
})

export class AppRoutingModule {}






import { IMovieDetails } from "./movie-details.interface";

export class MovieDetails implements IMovieDetails {
    movieId: number;
    title: string;
    comments: string;
    voteCount: number;
    voteAverage: number;
    popularity: number;
    posterPath: string;
    backDropPath: string;
    adult: boolean;
    overview: string;
    releaseDate: string;
    video: string;
    originalTitle: string;
    originalLanguage: string;
    watchListId: number;
}
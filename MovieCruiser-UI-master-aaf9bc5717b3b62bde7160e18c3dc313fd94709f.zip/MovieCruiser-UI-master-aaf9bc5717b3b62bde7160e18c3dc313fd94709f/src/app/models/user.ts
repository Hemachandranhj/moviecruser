export class User {
    public userId: string;
    public password: string;
    public mobileNumber: string;
    public firstName: string;
    public lastName: string;    
}
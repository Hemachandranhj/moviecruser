import { MovieDetails } from "./movie-details";

export class MovieResults {
    results: MovieDetails[];
}
import { Component, OnInit } from "@angular/core";
import { Router, ActivatedRoute, Params } from "@angular/router";

import { IMovieDetails } from "../models/movie-details.interface";
import { MovieDetails } from "../models/movie-details";
import { MovieService } from "../services/movies.service";
import { WishListService } from "../services/wishList.service";

@Component({
    templateUrl: "./movie-details.component.html"
})

export class MovieDetailsComponent implements OnInit {

    movieDetails: IMovieDetails;
    movieDetailsList: MovieDetails[];
    id: number;
    showAddMovieButton = true;
    movieWatchListId: string;

    constructor(private movieService: MovieService,
        private wishListService: WishListService,
        private route: ActivatedRoute,
        private router: Router) { }

    // on init to load the movie details, recommeded movies and validate movie already exist        
    ngOnInit() {
        this.route.params.subscribe((params: Params) => {
            this.id = params["id"];
            this.getMovieDetails();
            this.getRecommendedMovies();
            this.validateMovieAlreadyExist(this.id);
        });
    }    

    // method to save the movie details in wishlist
    saveWishList(movie: IMovieDetails) {
        this.wishListService.post(movie).subscribe(
            (response) => {
                window.alert(response);
                this.router.navigate(['/wishList']);
            },
            error => {
                window.alert(error);
            });
    }

    // method to delete the movie in wish list if already exists
    delete() {
        this.wishListService.deleteWishList((+this.movieWatchListId)).subscribe(
            (response) => {
                window.alert(response);
                this.showAddMovieButton = true;
                this.movieWatchListId = "";
            },
            error => {
                window.alert(error.error);
            });
    }

    // method to validate the movie already exist or not
    private validateMovieAlreadyExist(id: number){
        this.wishListService.getWishList().subscribe(
            (response) => {
                var movieDetails = response.filter((movie) => {
                    return movie.movieId === +id;
                });
                this.showAddMovieButton = (movieDetails.length > 0) ? false : true;
                this.movieWatchListId = (movieDetails.length > 0) ? movieDetails[0].watchListId : "";
            },
            error => {
                window.alert(error);
            });
    }

    // method to get movie details
    private getMovieDetails() {
        this.movieService.getById(this.id).subscribe((response) => {
            this.movieDetails = response;
        });
    }

    // method to get recommended movies
    private getRecommendedMovies() {
        this.movieService.getRecommendedMovies(this.id).subscribe((response) => {
            this.movieDetailsList = response.results;
        });
    }
}
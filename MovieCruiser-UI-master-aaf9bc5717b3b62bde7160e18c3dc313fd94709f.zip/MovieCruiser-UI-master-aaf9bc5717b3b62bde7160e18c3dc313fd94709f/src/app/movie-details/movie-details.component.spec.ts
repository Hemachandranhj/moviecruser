import { TestBed } from "@angular/core/testing";
import { of } from "rxjs";

import { NO_ERRORS_SCHEMA } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import { MovieService } from "../services/movies.service";
import { WishListService } from "../services/wishList.service";
import { MovieDetails } from "../models/movie-details";
import { MovieDetailsComponent } from "./movie-details.component";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MovieResults } from "../models/movie-results";

describe("MovieDetailsComponent", () => {

    let movieService: MovieService;
    let wishListService: WishListService;
    let router: Router;
    let componentInstance: any;
    const movieDetails: MovieDetails = {
        "movieId": 234567,
        "title": "test",
        "comments": "test",
        "voteCount": 6,
        "voteAverage": 7,
        "popularity": 6,
        "posterPath": "test/test",
        "backDropPath": "test/test",
        "adult": true,
        "overview": "good",
        "releaseDate": "22-04-1987",
        "video": "test",
        "originalTitle": "test",
        "originalLanguage": "en_US",
        "watchListId": 1
    }
    const movieResults: MovieResults = {
        results: [movieDetails]
    };
    const dummyActivatedRoute: any = {
        "params": of({ id: 1 }),
        "snapshot": {
            "params": { "id": 20938 }
        }
    }

    beforeEach(() => {
        movieService = jasmine.createSpyObj("MovieService", ["getById", "getRecommendedMovies"]);
        ((movieService.getById) as jasmine.Spy).and.returnValue(of(null));
        ((movieService.getRecommendedMovies) as jasmine.Spy).and.returnValue(of(movieResults));        
        wishListService = jasmine.createSpyObj("WishListService", ["post", "deleteWishList"]);
        ((wishListService.post) as jasmine.Spy).and.returnValue(of(null));
        ((wishListService.deleteWishList) as jasmine.Spy).and.returnValue(of(null));
        router = jasmine.createSpyObj("router", ["navigate"]);

        componentInstance = new MovieDetailsComponent(movieService, wishListService, dummyActivatedRoute, router);
    });

    it("should create a component", () => {

        TestBed.configureTestingModule({
            imports: [
                FormsModule,
                ReactiveFormsModule
            ],
            declarations: [MovieDetailsComponent],
            providers: [
                { provide: ActivatedRoute, useValue: dummyActivatedRoute },
                { provide: MovieService, useValue: movieService },
                { provide: WishListService, useValue: wishListService },
                { provide: Router, useValue: router }
            ],
            schemas: [NO_ERRORS_SCHEMA]
        });

        const fixture = TestBed.createComponent(MovieDetailsComponent);
        const component = fixture.componentInstance;
        expect(component).toBeTruthy();
    });

    it("should call the services as expected", () => {

        // Act
        componentInstance.ngOnInit();

        // Assert
        expect(movieService.getById).toHaveBeenCalled();
        expect(movieService.getRecommendedMovies).toHaveBeenCalled();

    });

    it("should call the wishlist service as expected", () => {

        // Act
        componentInstance.saveWishList(movieDetails);

        // Assert
        expect(wishListService.post).toHaveBeenCalled();
    });

    it("should call the wishlist delete service as expected", () => {

        // Arrange
        componentInstance.movieWatchListId = "5";

        // Act
        componentInstance.delete();

        // Assert
        expect(wishListService.deleteWishList).toHaveBeenCalled();
    });
});

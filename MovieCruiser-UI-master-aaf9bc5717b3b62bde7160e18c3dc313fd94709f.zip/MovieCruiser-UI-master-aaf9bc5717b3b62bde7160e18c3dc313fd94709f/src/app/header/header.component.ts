import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { AuthenticationService } from "../services/authentication.service";

@Component({
 selector: 'header',
 templateUrl: "./header.component.html",
})

export class HeaderComponent implements OnInit {

    movieSearch: string;
    isLoggedIn: boolean;
    
    constructor(private router: Router, private authService: AuthenticationService){}
    
    // On init to reset the search text and get response for user logged in or not
    ngOnInit(){
        this.resetSearch();
        this.authService.isLoggedIn.subscribe((response) => {
            this.isLoggedIn = response;
        });
    }

    // method to search the movie
    onSearch() {
        if(this.movieSearch == '')
        {
            this.router.navigate(['/popularMovies']);
            return;
        }
        this.router.navigate(['/search'], {queryParams: { search: this.movieSearch }, skipLocationChange: false });
    }

    // method to reset the search text
    private resetSearch(): void {
        this.movieSearch = '';
    }
}
import { Router } from "@angular/router";
import { HeaderComponent } from "./header.component";
import { AuthenticationService } from "../services/authentication.service";

describe("HeaderComponent", () => {
  
    let router: Router;
    let authService: AuthenticationService;
    let componentInstance: any;
    const searchText ="Deadpool";   

    beforeEach(() => {
        authService = jasmine.createSpyObj("AuthenticationService", ["isLoggedIn"]);

        router = jasmine.createSpyObj("router", ["navigate"]);

        componentInstance = new HeaderComponent(router, authService);
    });

    it("should create a component", () => {
        // Assert
        expect(componentInstance).toBeTruthy();
    });

    it("should call the search method with search text as expected", () => {

        // Arrange
        componentInstance.movieSearch = searchText;
        
        // Act
        componentInstance.onSearch();

        // Assert
        expect(router.navigate).toHaveBeenCalledWith(['/search'], {queryParams: { search: searchText }, skipLocationChange: false });
    });

    it("should call the search method without search text as expected", () => {

        // Arrange
        componentInstance.movieSearch = "";
        
        // Act
        componentInstance.onSearch();

        // Assert
        expect(router.navigate).toHaveBeenCalledWith(['/popularMovies']);
    });
});

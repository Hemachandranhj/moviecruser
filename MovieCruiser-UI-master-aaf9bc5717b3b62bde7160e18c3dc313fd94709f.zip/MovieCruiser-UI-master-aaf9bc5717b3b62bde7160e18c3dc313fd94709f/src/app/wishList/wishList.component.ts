import { Component, OnInit } from '@angular/core';
import { IMovieDetails } from '../models/movie-details.interface';
import { WishListService } from '../services/wishList.service';

@Component({
    templateUrl: './wishList.component.html',
})

export class WishListComponent implements OnInit {

    movies: IMovieDetails[];

    constructor(private wishListService: WishListService) { }

    ngOnInit() {
        this.getMoviesWishList();
    }

    update(movie: IMovieDetails) {
        this.wishListService.put(movie).subscribe(
            (response) => {
                window.alert(response);
            });
    }

    delete(id: number) {
        this.wishListService.deleteWishList(id).subscribe(
            (response) => {
                window.alert(response);
                this.getMoviesWishList();
            });
    }

    private getMoviesWishList() {
        this.wishListService.getWishList().subscribe(
            (result) => {
                this.movies = result;
            });
    }
}
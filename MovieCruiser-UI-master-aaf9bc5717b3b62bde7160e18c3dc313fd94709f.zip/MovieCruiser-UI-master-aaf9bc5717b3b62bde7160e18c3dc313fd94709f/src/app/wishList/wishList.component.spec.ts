import { TestBed } from "@angular/core/testing";
import { of } from "rxjs";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { WishListService } from "../services/wishList.service";
import { MovieDetails } from "../models/movie-details";
import { MovieResults } from "../models/movie-results";
import { WishListComponent } from "./wishList.component";

describe("WishListComponent", () => {

    let wishListService: WishListService;
    let componentInstance: any;
    const movieDetails: MovieDetails = {
        "movieId": 234567,
        "title": "test",
        "comments": "test",
        "voteCount": 6,
        "voteAverage": 7,
        "popularity": 6,
        "posterPath": "test/test",
        "backDropPath": "test/test",
        "adult": true,
        "overview": "good",
        "releaseDate": "22-04-1987",
        "video": "test",
        "originalTitle": "test",
        "originalLanguage": "en_US",
        "watchListId": 1
    }

    const movieDetailsList = [movieDetails];

    beforeEach(() => {
        wishListService = jasmine.createSpyObj("MovieService", ["getWishList", "deleteWishList", "put"]);       
        ((wishListService.getWishList) as jasmine.Spy).and.returnValue(of(movieDetailsList));
        ((wishListService.deleteWishList) as jasmine.Spy).and.returnValue(of(true));
        ((wishListService.put) as jasmine.Spy).and.returnValue(of(null));
        componentInstance = new WishListComponent(wishListService);
    });

    it("should create a component", () => {

        TestBed.configureTestingModule({
            imports: [
                FormsModule,
                ReactiveFormsModule
            ],
            declarations: [WishListComponent],
            providers: [
                { provide: WishListService, useValue: wishListService }
            ],
            schemas: [NO_ERRORS_SCHEMA]
        });

        const fixture = TestBed.createComponent(WishListComponent);
        const component = fixture.componentInstance;
        expect(component).toBeTruthy();
    });

    it("should call the wishlist service getWishList method as expected", () => {

        // Act
        componentInstance.ngOnInit();

        // Assert
        expect(wishListService.getWishList).toHaveBeenCalled();

    });

    it("should call the wishlist service delete method as expected", () => {
       
        // Act
        componentInstance.delete(12);

        // Assert
        expect(wishListService.deleteWishList).toHaveBeenCalled();
    });

    it("should call the wishlist service put method as expected", () => {
       
        // Act
        componentInstance.update(movieDetails);

        // Assert
        expect(wishListService.put).toHaveBeenCalled();
    });
});

﻿namespace server.Services
{
    using server.Data.Repository;
    using server.Models;
    using System.Collections.Generic;

    public class NewsService: INewsService
    {
        private readonly INewsRepository _repository;

        public NewsService(INewsRepository repository)
        {
            _repository = repository;
        }

        /// <summary>
        /// Get all the favorite news. 
        /// </summary>
        /// <returns></returns>
        public IList<NewsDetail> GetAll()
        {
            return _repository.GetAll();
        }                

        /// <summary>
        /// Add a new favorite news.
        /// </summary>
        /// <param name="news"></param>
        /// <returns></returns>
        public int Add(NewsDetail news)
        {
            return _repository.Add(news);
        }

        /// <summary>
        /// Delete a favorite news.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool Delete(int id)
        {
            return _repository.Delete(id);
        }
    }
}

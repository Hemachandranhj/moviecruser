﻿namespace server.Services
{
    using System.Collections.Generic;
    using server.Models;

    public interface INewsService
    {
        IList<NewsDetail> GetAll();      
        int Add(NewsDetail news);
        bool Delete(int id);
    }
}

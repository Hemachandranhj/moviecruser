﻿namespace server.Controllers
{
    using System;   
    using System.Net.Http;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Configuration;

    [Route("api/News")]
    public class NewsController : Controller
    {        
        private HttpClient httpClient;
        private readonly IConfiguration config;

        /// <summary>
        /// constructor for the news controller
        /// </summary>
        /// <param name="httpClient"></param>
        /// <param name="config"></param>
        public NewsController(HttpClient httpClient, IConfiguration config)
        {
            this.httpClient = httpClient;
            this.config = config;         

        }

        /// <summary>
        /// Get top news headlines.
        /// </summary>
        /// <returns></returns>
        [HttpGet("gettopnewsheadlines")]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public async Task<IActionResult> GetTopNewsHeadLines()
        {
            try
            {
                var url = this.config["NewsAPIHeadlinesUrl"].ToString();
                HttpResponseMessage response = await httpClient.GetAsync(url).ConfigureAwait(false);
                response.EnsureSuccessStatusCode();
                var result = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                return new OkObjectResult(result);
            }
            catch (Exception)
            {
                return new BadRequestObjectResult("Server error occured");
            }
        }

        /// <summary>
        /// Get the news category for the category type which we passed.
        /// </summary>
        /// <param name="category"></param>
        /// <returns></returns>
        [HttpGet("{category}")]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public async Task<IActionResult> GetCategoryNews(string category)
        {
            try
            {
                var url = this.config["NewsAPICategoryUrl"].ToString().Replace("{category}", category);
                HttpResponseMessage response = await httpClient.GetAsync(url).ConfigureAwait(false);
                response.EnsureSuccessStatusCode();
                var result = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                return new OkObjectResult(result);
            }
            catch (Exception)
            {
                return new BadRequestObjectResult("Server error occured");
            }
        }

        /// <summary>
        /// Search the news text and returns the matchced news
        /// </summary>
        /// <param name="searchText"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("search/{searchText}")]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public async Task<IActionResult> Search(string searchText)
        {
            try
            {
                var url = this.config["NewsAPISearchUrl"].ToString().Replace("{searchText}", searchText);
                HttpResponseMessage response = await httpClient.GetAsync(url).ConfigureAwait(false);
                response.EnsureSuccessStatusCode();
                var result = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                if (response == null)
                {
                    return new NotFoundResult();
                }
                return new OkObjectResult(result);
            }
            catch (Exception)
            {
                return new BadRequestObjectResult("Server error occured");
            }
        }


    }
}
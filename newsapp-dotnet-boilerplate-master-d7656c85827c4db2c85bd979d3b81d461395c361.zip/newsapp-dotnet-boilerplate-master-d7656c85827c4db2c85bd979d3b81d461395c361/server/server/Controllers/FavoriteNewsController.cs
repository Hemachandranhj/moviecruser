﻿namespace server.Controllers
{
    using System;   
    using Microsoft.AspNetCore.Mvc;
    using server.Models;
    using server.Services;
 
    [Route("api/FavoriteNews")]
    public class FavoriteNewsController : Controller
    {
        private readonly INewsService _service;

        /// <summary>
        /// constructor for favorite news.
        /// </summary>
        /// <param name="service"></param>
        public FavoriteNewsController(INewsService service)
        {
            this._service = service;
        }        

        /// <summary>
        /// Get all favorite news.
        /// </summary>
        /// <returns>return list of favorite news</returns>
        // GET: api/FavoriteNews
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                return Ok(this._service.GetAll());
            }
            catch (Exception)
            {
                return StatusCode(500, "Server error occured");
            }
        }

        /// <summary>
        /// Add a new favorite news.
        /// </summary>
        /// <param name="newsDetail"></param>
        /// <returns></returns>
        // POST: api/FavoriteNews
        [HttpPost]
        public IActionResult Post([FromBody] NewsDetail newsDetail)
        {
            try
            {
                var response = this._service.Add(newsDetail);

                if (response > 0)
                {
                    return StatusCode(201);
                }

                return StatusCode(409);
            }
            catch (Exception)
            {
                return StatusCode(500, "Server error occured.");
            }
        }

        /// <summary>
        /// Delete a favorite news.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                var response = this._service.Delete(id);

                if (response)
                {
                    return Ok(response);
                }

                return NotFound();
            }
            catch (Exception)
            {
                return StatusCode(500, "Server error occured.");
            }
        }

    }
}
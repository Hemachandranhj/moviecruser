﻿namespace server.Data.Context
{
    using Microsoft.EntityFrameworkCore;
    using server.Data.Entities;

    public class NewsDbContext : DbContext, INewsDbContext
    {
        public NewsDbContext() { }

        public NewsDbContext(DbContextOptions<NewsDbContext> contextOptions): base(contextOptions)
        {
            Database.EnsureCreated();
        }

        public DbSet<News> News { get; set; }
    }
}

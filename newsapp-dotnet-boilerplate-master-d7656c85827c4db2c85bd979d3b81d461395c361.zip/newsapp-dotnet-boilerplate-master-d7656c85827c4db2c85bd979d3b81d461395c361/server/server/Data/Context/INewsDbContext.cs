﻿namespace server.Data.Context
{
    using Microsoft.EntityFrameworkCore;
    using server.Data.Entities;

    public interface INewsDbContext
    {
        DbSet<News> News { get; set; }

        int SaveChanges();
    }
}

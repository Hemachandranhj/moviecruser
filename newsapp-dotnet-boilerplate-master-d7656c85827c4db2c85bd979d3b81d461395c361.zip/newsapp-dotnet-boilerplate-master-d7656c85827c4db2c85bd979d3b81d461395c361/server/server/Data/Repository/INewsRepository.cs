﻿namespace server.Data.Repository
{
    using System.Collections.Generic;
    using server.Models;

    public interface INewsRepository
    {
        IList<NewsDetail> GetAll();
        int Add(NewsDetail news);
        bool Delete(int id);
    }
}

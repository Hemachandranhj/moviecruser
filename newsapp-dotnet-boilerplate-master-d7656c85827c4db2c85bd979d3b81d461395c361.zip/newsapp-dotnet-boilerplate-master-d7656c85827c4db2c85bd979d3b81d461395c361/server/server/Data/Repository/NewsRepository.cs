﻿namespace server.Data.Repository
{
    using System.Linq;
    using System.Collections.Generic;
    using server.Data.Context;
    using server.Models;
    using server.Data.Entities;

    public class NewsRepository: INewsRepository
    {
        private readonly INewsDbContext _context;

        /// <summary>
        /// favorite news constructor
        /// </summary>
        /// <param name="context"></param>
        public NewsRepository(INewsDbContext context)
        {
            _context = context;
        }

       /// <summary>
       /// get all favorite news 
       /// </summary>
       /// <returns></returns>
        public IList<NewsDetail> GetAll()
        {
            return _context.News.Select(newsDetails => new NewsDetail
            {
                Id = newsDetails.Id,
                SourceId = newsDetails.SourceId,
                SourceName = newsDetails.SourceName,
                Title = newsDetails.Title,
                Description = newsDetails.Description,
                Url = newsDetails.Url,
                UrlToImage = newsDetails.UrlToImage,
                PublishedAt = newsDetails.PublishedAt
            }).ToList();
        }

       /// <summary>
       /// add a new favorite news
       /// </summary>
       /// <param name="news"></param>
       /// <returns></returns>
        public int Add(NewsDetail news)
        {
            var newsDetail = _context.News.SingleOrDefault(x => x.Title.ToLower() == news.Title.ToLower());

            if (newsDetail != null)
            {
                return 0;
            }

            var favNews = new News()
            {
                SourceId = news.SourceId,
                SourceName = news.SourceName,
                Title = news.Title,
                Description = news.Description,
                Url = news.Url,
                UrlToImage = news.UrlToImage,
                PublishedAt = news.PublishedAt
            };

            _context.News.Add(favNews);
            return _context.SaveChanges();
        }

      /// <summary>
      /// delete a favorite news
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
        public bool Delete(int id)
        {
            var wishList = _context.News.Find(id);

            if(wishList != null)
            {
                _context.News.Remove(wishList);
                _context.SaveChanges();
                return true;
            }

            return false;
        }


    }
}


﻿namespace test.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using Moq;
    using server.Controllers;
    using server.Models;
    using server.Services;
    using System;
    using System.Collections.Generic;
    using Xunit;

    public class FavoriteNewsControllerTest
    {
        [Fact]
        public void GetAllMethod_ShouldReturnFavoriteNewsListAsExpected()
        {
            // Arrange
            var mockService = new Mock<INewsService>();
            mockService.Setup(s => s.GetAll()).Returns(this.GetFavoriteNewsList());
            var controller = new FavoriteNewsController(mockService.Object);

            // Act
            var result = controller.Get();
            var actualResult = result as OkObjectResult;

            // Assert
            Assert.NotNull(actualResult.Value);
        }

        [Fact]
        public void GetAllMethod_ShouldCatchExceptionAsExpected()
        {
            // Arrange
            var mockService = new Mock<INewsService>();
            mockService.Setup(s => s.GetAll()).Throws(new Exception());
            var controller = new FavoriteNewsController(mockService.Object);

            // Act
            var result = controller.Get();
            var actualResult = result as ObjectResult;

            // Assert
            Assert.Equal(500, actualResult.StatusCode);
        }

        [Fact]
        public void PostMethod_ShouldAddFavoriteNewsAsExpected()
        {
            // Arrange
            var favNews = new NewsDetail()
            {
                SourceId = "TimesOfIndia",
                SourceName = "TimesOfIndia",
                Author = "Test test",
                Title = "Testtt23",
                Description = "Test",
                Url = "test",
                UrlToImage = "terste",
                PublishedAt = DateTime.Now
            };
            var mockService = new Mock<INewsService>();
            mockService.Setup(s => s.Add(It.IsAny<NewsDetail>())).Returns(1);
            var controller = new FavoriteNewsController(mockService.Object);

            // Act
            var result = controller.Post(favNews) as StatusCodeResult;           

            // Assert          
            Assert.NotNull(result);
            Assert.Equal(201, result.StatusCode);
        }

        [Fact]
        public void Post_ShouldNotSaveTheFavoriteNewsForAlreadyAddedNews()
        {
            // Arrange 
            var favNews = new NewsDetail()
            {
                SourceId = "TimesOfIndia",
                SourceName = "TimesOfIndia",
                Author = "Test test",
                Title = "Testtt23",
                Description = "Test",
                Url = "test",
                UrlToImage = "terste",
                PublishedAt = DateTime.Now
            };
            var mockService = new Mock<INewsService>();
            mockService.Setup(s => s.Add(It.IsAny<NewsDetail>())).Returns(0);
            var controller = new FavoriteNewsController(mockService.Object);

            // Act
            var result = controller.Post(favNews) as StatusCodeResult;

            //Assert    
            Assert.NotNull(result);
            Assert.Equal(409, result.StatusCode);
        }

        [Fact]
        public void Post_ShouldCatchExceptionAsException()
        {
            // Arrange 
            var favNews = new NewsDetail()
            {
                SourceId = "TimesOfIndia",
                SourceName = "TimesOfIndia",
                Author = "Test test",
                Title = "Testtt23",
                Description = "Test",
                Url = "test",
                UrlToImage = "terste",
                PublishedAt = DateTime.Now
            };
            var mockService = new Mock<INewsService>();
            mockService.Setup(s => s.Add(It.IsAny<NewsDetail>())).Throws(new Exception());
            var controller = new FavoriteNewsController(mockService.Object);

            // Act
            var result = controller.Post(favNews) as ObjectResult;

            // Assert
            Assert.Equal(500, result.StatusCode);
        }

        [Fact]
        public void DeleteMethod_ShouldRemoveMoviesWishListAsExpected()
        {
            // Arrange            
            var mockService = new Mock<INewsService>();
            mockService.Setup(s => s.Delete(It.IsAny<int>())).Returns(true);
            var controller = new FavoriteNewsController(mockService.Object);

            // Act
            var result = controller.Delete(1) as OkObjectResult;

            // Assert
            Assert.True((bool)result.Value);
        }

        [Fact]
        public void Delete_OperationShouldNotDoneForInVaildId()
        {
            // Arrange
            var mockService = new Mock<INewsService>();
            mockService.Setup(s => s.Delete(It.IsAny<int>())).Returns(false);
            var controller = new FavoriteNewsController(mockService.Object);

            // Act
            var result = controller.Delete(556767) as NotFoundResult;

            //Assert
            Assert.NotNull(result);
            Assert.Equal(404, result.StatusCode);

        }

        [Fact]
        public void Delete_OperationShouldCatchExceptionAsExpected()
        {
            // Arrange
            var mockService = new Mock<INewsService>();
            mockService.Setup(s => s.Delete(It.IsAny<int>())).Throws(new Exception());
            var controller = new FavoriteNewsController(mockService.Object);

            // Act
            var result = controller.Delete(555) as ObjectResult;

            //Assert
            Assert.Equal(500, result.StatusCode);

        }

        private List<NewsDetail> GetFavoriteNewsList()
        {
            List<NewsDetail> favNewsList = new List<NewsDetail>
            {
                new NewsDetail{
                    Id = 1,
                    SourceId = "TimesOfIndia",
                    SourceName = "TimesOfIndia",
                    Author = "Test test",
                    Title = "Testtt12",
                    Description = "Test",
                    Url = "test",
                    UrlToImage = "terste",
                    PublishedAt = DateTime.Now
                },

                new NewsDetail{
                    Id = 2,
                    SourceId = "TimesOfIndia",
                    SourceName = "TimesOfIndia",
                    Author = "Test test",
                    Title = "Testtt34",
                    Description = "Test",
                    Url = "test",
                    UrlToImage = "terste",
                    PublishedAt = DateTime.Now
                }
            };

            return favNewsList;
        }
    }
}

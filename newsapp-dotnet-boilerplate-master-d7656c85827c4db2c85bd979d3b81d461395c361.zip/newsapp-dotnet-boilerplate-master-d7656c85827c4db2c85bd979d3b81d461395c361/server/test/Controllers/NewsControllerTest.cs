﻿namespace test.Controllers
{
    using Microsoft.AspNetCore.Mvc;   
    using Moq;
    using Moq.Protected;
    using Newtonsoft.Json;    
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using Xunit;
    using server.Controllers;
    using Microsoft.Extensions.Configuration;

    public class NewsControllerTest
    {
        [Fact]
        public async Task GetTopNewsHeadlinesReturnsAsExpectedResults()
        {
            //Arrange           
            var mockHttpClient = MockHttpClient(HttpStatusCode.OK);
            var controller = new NewsController(mockHttpClient, Config());

            //Act
            var result = await controller.GetTopNewsHeadLines() as OkObjectResult;

            //Assert
            Assert.NotNull(result);
            Assert.Equal(200, result.StatusCode);
        }

        [Fact]
        public async Task GetTopNewsHeadlinesBadRequestsExpectedResult()
        {
            //Arrange
            var mockHttpClient = MockHttpClient(HttpStatusCode.BadRequest);
            var controller = new NewsController(mockHttpClient, Config());

            //Act
            var result = await controller.GetTopNewsHeadLines() as BadRequestObjectResult;

            //Assert
            Assert.NotNull(result);
            Assert.Equal(400, result.StatusCode);
            Assert.Equal("Server error occured", result.Value);
        }

        [Fact]
        public async Task GetCategoryNewsReturnsAsExpectedResult()
        {
            //Arrange
            var mockHttpClient = MockHttpClient(HttpStatusCode.OK);
            var controller = new NewsController(mockHttpClient, Config());

            //Act
            var result = await controller.GetCategoryNews("health") as OkObjectResult;

            //Assert
            Assert.NotNull(result);
            Assert.Equal(200, result.StatusCode);
        }

        [Fact]
        public async Task GetCategoryNewsBadRequestAsExpectedResult()
        {
            //Arrange
            var mockHttpClient = MockHttpClient(HttpStatusCode.BadRequest);
            var controller = new NewsController(mockHttpClient, Config());

            //Act
            var result = await controller.GetCategoryNews("health") as BadRequestObjectResult;

            //Assert
            Assert.NotNull(result);
            Assert.Equal(400, result.StatusCode);
            Assert.Equal("Server error occured", result.Value);
        }

        [Fact]
        public async Task GetSearchNewsReturnsAsExpectedResult()
        {
            //Arrange
            var mockHttpClient = MockHttpClient(HttpStatusCode.OK);
            var controller = new NewsController(mockHttpClient, Config());

            //Act
            var result = await controller.Search("Test") as OkObjectResult;

            //Assert
            Assert.NotNull(result);
            Assert.Equal(200, result.StatusCode);
        }

        [Fact]
        public async Task GetSearchNewsBadRequestAsExpectedResult()
        {
            //Arrange
            var mockHttpClient = MockHttpClient(HttpStatusCode.BadRequest);
            var controller = new NewsController(mockHttpClient, Config());

            //Act
            var result = await controller.Search("Xioami Results") as BadRequestObjectResult;

            //Assert
            Assert.NotNull(result);
            Assert.Equal(400, result.StatusCode);
            Assert.Equal("Server error occured", result.Value);
        }

        private static IConfiguration Config()
        {
            var configuration = new ConfigurationBuilder()
                    .AddJsonFile("appsettings.testing.json", false)
                    .Build();
            return configuration;
        }

        private static HttpClient MockHttpClient(HttpStatusCode httpClientStatus)
        {           
            var httpMessageHandler = new Mock<HttpMessageHandler>();
            httpMessageHandler
                    .Protected()
                    .Setup<Task<HttpResponseMessage>>("SendAsync", ItExpr.IsAny<HttpRequestMessage>(), ItExpr.IsAny<CancellationToken>())
                    .Returns(Task.FromResult(new HttpResponseMessage
                    {
                        StatusCode = httpClientStatus,
                        Content = new StringContent(JsonConvert.SerializeObject(MockNewsApiResponse()), Encoding.UTF8, "application/json")
                    }));
            var httpClient = new HttpClient(httpMessageHandler.Object);
            return httpClient;
        }

        private static object MockNewsApiResponse()
        {           
            var newsApiResponse = new
            {
                status = "ok",
                totalResults = 2,
                articles = new List<object>{
                    new {
                    id = 24,
                    name = "Indianexpress.com",                 
                    author = "test",
                    title = "Anushka Sharma playing for Team India?' BCCI slammed on social media for image",
                    description= "test"
                   },
                     new {
                    id = 25,
                    name = "Indianexpress.com",
                    author = "test12",
                    title = "Anushka image",
                    description= "test1"
                   }
                }
            };
            return newsApiResponse;
        }
    }
}

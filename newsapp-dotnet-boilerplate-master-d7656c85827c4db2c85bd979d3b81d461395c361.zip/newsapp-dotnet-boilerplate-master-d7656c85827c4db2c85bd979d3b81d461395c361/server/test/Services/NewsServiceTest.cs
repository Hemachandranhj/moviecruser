﻿namespace test.Services
{   
    using Moq;
    using server.Models;
    using server.Data.Repository;
    using System;
    using System.Collections.Generic;
    using Xunit;
    using server.Services;

    public class NewsServiceTest
    {
        [Fact]
        public void GetAllMethod_ShouldReturnFavoriteNewsAsExpected()
        {
            // Arrange
            var mockRepository = new Mock<INewsRepository>();
            mockRepository.Setup(s => s.GetAll()).Returns(this.GetFavoriteNewsList());
            var service = new NewsService(mockRepository.Object);

            // Act
            var result = service.GetAll() as List<NewsDetail>;

            // Assert
            Assert.Equal(2, result.Count);
        }       

        [Fact]
        public void PostMethod_ShouldAddFavoriteNewsAsExpected()
        {
            // Arrange
            var favNews = new NewsDetail()
            {                
                SourceId = "TimesOfIndia",
                SourceName = "TimesOfIndia",
                Author = "Test test",
                Title = "Testtt23",
                Description = "Test",
                Url = "test",
                UrlToImage = "terste",
                PublishedAt = DateTime.Now
            };
            var mockRepository = new Mock<INewsRepository>();
            mockRepository.Setup(s => s.Add(It.IsAny<NewsDetail>())).Returns(1);
            var service = new NewsService(mockRepository.Object);

            // Act
            var result = service.Add(favNews);

            // Assert
            Assert.Equal(1, result);
        }       

        [Fact]
        public void DeleteMethod_ShouldRemoveFavoriteNewsAsExpected()
        {
            // Arrange            
            var mockRepository = new Mock<INewsRepository>();
            mockRepository.Setup(s => s.Delete(It.IsAny<int>())).Returns(true);
            var service = new NewsService(mockRepository.Object);

            // Act
            var result = service.Delete(1);

            // Assert

            Assert.True(result);
        }

        private List<NewsDetail> GetFavoriteNewsList()
        {
            List<NewsDetail> favNewsList = new List<NewsDetail>
            {
                new NewsDetail{
                    Id = 1,
                    SourceId = "TimesOfIndia",
                    SourceName = "TimesOfIndia",
                    Author = "Test test",
                    Title = "Testtt12",
                    Description = "Test",
                    Url = "test",
                    UrlToImage = "terste",
                    PublishedAt = DateTime.Now
                },

                new NewsDetail{
                    Id = 2,
                    SourceId = "TimesOfIndia",
                    SourceName = "TimesOfIndia",
                    Author = "Test test",
                    Title = "Testtt34",
                    Description = "Test",
                    Url = "test",
                    UrlToImage = "terste",
                    PublishedAt = DateTime.Now
                }
            };

            return favNewsList;
        }
    }
}

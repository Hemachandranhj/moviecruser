﻿namespace test.Data
{
    using Microsoft.EntityFrameworkCore;
    using server.Data.Context;
    using server.Data.Entities;
    using System;

    public class DatabaseFixture : IDisposable
    {
        public INewsDbContext dbContext;

        public DatabaseFixture()
        {
            var dbContextOptions = new DbContextOptionsBuilder<NewsDbContext>().UseInMemoryDatabase(databaseName: "News").Options;
            dbContext = new NewsDbContext(dbContextOptions);

            dbContext.News.Add(new News
            {
                Id = 105,
                SourceId = "TimesOfIndia",
                SourceName = "TimesOfIndia",
                Author = "Test test",
                Title = "Testtt",
                Description = "Test",
                Url = "test",
                UrlToImage = "terste",
                PublishedAt = DateTime.Now
            });

            dbContext.News.Add(new News
            {
                Id = 106,
                SourceId = "IndianExpress",
                SourceName = "IndianExpress",
                Author = "Test test",
                Title = "Testtt",
                Description = "Test",
                Url = "test",
                UrlToImage = "test",
                PublishedAt = DateTime.Now
            });

            dbContext.SaveChanges();
        }

        public void Dispose()
        {
            dbContext = null;
        }
    }
}

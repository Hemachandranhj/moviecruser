﻿namespace test.Data
{
    using server.Models;
    using server.Data.Repository;
    using System;
    using Xunit;
    using System.Linq;

    public class NewsRepositoryTest: IClassFixture<DatabaseFixture>
    {
        private readonly DatabaseFixture _fixture;
        private readonly INewsRepository _repository;

        public NewsRepositoryTest(DatabaseFixture fixture)
        {
            this._fixture = fixture;
            this._repository = new NewsRepository(this._fixture.dbContext);
        }

        [Fact]
        public void GetAllMethod_ShouldReturnFavoriteNewsAsExpected()
        {
            // Act
            var newsDetail = this._repository.GetAll();
            var expectedResult = this._fixture.dbContext.News;

            // Assert
            Assert.Equal(expectedResult.Count(), newsDetail.Count());

        }        

        [Fact]
        public void PostMethod_ShouldAddFavoriteNewsAsExpected()
        {
            // Arrange
            var expected = this._fixture.dbContext.News.Count() + 1;
            var news = new NewsDetail
            {
                Id = 555,
                SourceId = "TimesOfIndia",
                SourceName = "TimesOfIndia",
                Author = "Test test",
                Title = "Tttt",
                Description = "Test",
                Url = "test",
                UrlToImage = "terste",
                PublishedAt = DateTime.Now
            };

            // Act
            this._repository.Add(news);

            // Assert
            Assert.Equal(expected, this._fixture.dbContext.News.Count());
        }        

        [Fact]
        public void DeleteMethod_ShouldRemoveFavoriteNewsAsExpected()
        {

            // Act
            var actual = this._repository.Delete(106);

            // Assert
            Assert.True(actual);

        }
    }
}

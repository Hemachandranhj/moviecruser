import { CommonPage } from './common.po';

describe('Dashboard Page', () => {

    it('should navigate to dashboard page', () => {
        CommonPage.getCurrentUrl()
            .then((url) => {
                expect(url).toMatch('home');
            });
    });

    it('should see the title for top news head lines', () => {
        expect(CommonPage.getSectionText("newsTopHeadLines")).toBe("Top News HeadLines");
    });

    it('should see the title for news category', () => {
        expect(CommonPage.getSectionText("categoryNews")).toBe("News Category");
    });

    it('should see the news loaded on top news head lines', () => {
        CommonPage.waitPresenceOfElement(CommonPage.sectionNewsAvailable("headlines")).then(() => {
            expect(CommonPage.sectionNewsAvailable("headlines").isPresent()).toBeTruthy();
        });
    });

    it('should see the news loaded on category news', () => {
        CommonPage.waitPresenceOfElement(CommonPage.sectionNewsAvailable("category")).then(() => {
            expect(CommonPage.sectionNewsAvailable("category").isPresent()).toBeTruthy();
        });
    });

    it('should add the news to favorites on top news head lines news', () => {
        CommonPage.waitPresenceOfElement(CommonPage.sectionNewsAvailable("headlines")).then(() => {
            CommonPage.addFavoriteNews("headlines").then(() => {
                CommonPage.waitForAlert();
                CommonPage.acceptAlert().then(() => {
                    CommonPage.waitPresenceOfElement(CommonPage.buttonDisplayed('headlines', 'add')).then(() => {
                        expect(CommonPage.buttonDisplayed('headlines', 'add').isPresent()).toBeTruthy();
                    });
                });
            });
        });
    });

    it('should remove the news to favorites on top news head lines news', () => {
        CommonPage.waitPresenceOfElement(CommonPage.sectionNewsAvailable("headlines")).then(() => {
            CommonPage.removeFavoriteNews("headlines").then(() => {
                CommonPage.waitForAlert();
                CommonPage.acceptAlert().then(() => {
                    CommonPage.waitPresenceOfElement(CommonPage.buttonDisplayed('headlines', 'delete')).then(() => {
                        expect(CommonPage.buttonDisplayed('headlines', 'delete').isPresent()).toBeTruthy();
                    });
                });
            });
        });
    });

    it('should add the news to favorites on category news', () => {
        CommonPage.waitPresenceOfElement(CommonPage.sectionNewsAvailable("category")).then(() => {
            CommonPage.addFavoriteNews("category").then(() => {
                CommonPage.waitForAlert();
                CommonPage.acceptAlert().then(() => {
                    CommonPage.waitPresenceOfElement(CommonPage.buttonDisplayed('category', 'add')).then(() => {
                        expect(CommonPage.buttonDisplayed('category', 'add').isPresent()).toBeTruthy();
                    });
                });
            });
        });
    });

    it('should remove the news to favorites on category news', () => {
        CommonPage.waitPresenceOfElement(CommonPage.sectionNewsAvailable("category")).then(() => {
            CommonPage.removeFavoriteNews("category").then(() => {
                CommonPage.waitForAlert();
                CommonPage.acceptAlert().then(() => {
                    CommonPage.waitPresenceOfElement(CommonPage.buttonDisplayed('category', 'delete')).then(() => {
                        expect(CommonPage.buttonDisplayed('category', 'delete').isPresent()).toBeTruthy();
                    });
                });
            });
        });
    });


    it('should display the news by selected category on category news', () => {
        CommonPage.waitPresenceOfElement(CommonPage.sectionNewsAvailable("category")).then(() => {
            CommonPage.selectDropDownOption("Health").then(() => {
                CommonPage.waitPresenceOfElement(CommonPage.sectionNewsAvailable("category")).then(() => {
                    expect(CommonPage.currentDropDownSelectionText()).toBe("Health");
                    expect(CommonPage.sectionNewsAvailable("category").isPresent()).toBeTruthy();
                });
            });
        });
    });

    it('should display the news by search', () => {
        CommonPage.waitPresenceOfElement(CommonPage.sectionNewsAvailable("headlines")).then(() => {
            CommonPage.enterValues("search-text", "tamilnadu").then(() => {
                CommonPage.buttonClick("search-btn").then(() => {
                    CommonPage.getCurrentUrl()
                        .then((url) => {
                            expect(url).toMatch('search');
                            expect(CommonPage.getSectionText("serachNews")).toBe("Search News");
                            expect(CommonPage.sectionNewsAvailable("search").isPresent()).toBeTruthy();
                        });
                });
            });
        });
    });

});
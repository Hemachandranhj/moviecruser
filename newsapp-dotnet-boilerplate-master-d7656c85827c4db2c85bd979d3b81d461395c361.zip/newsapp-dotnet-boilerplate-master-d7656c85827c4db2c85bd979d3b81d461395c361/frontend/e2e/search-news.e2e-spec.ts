import { CommonPage } from './common.po';

describe('Search Page', () => {

    beforeEach(() => {
        CommonPage.navigateToFavoriteNews().then(() => {
            CommonPage.waitPresenceOfElement(CommonPage.sectionNewsAvailable("favorites")).then(() => {
                CommonPage.enterValues("search-text", "test").then(() => {
                    CommonPage.buttonClick("search-btn").then();
                });
            });
        });
    });

    it('should navigate to search page', () => {
        CommonPage.getCurrentUrl()
            .then((url) => {
                expect(url).toMatch('search');
            });
    });

    it('should see the title for search news', () => {
        expect(CommonPage.getSectionText("serachNews")).toBe("Search News");
    });

    it('should see the news loaded on top news head lines', () => {
        CommonPage.waitPresenceOfElement(CommonPage.sectionNewsAvailable("search")).then(() => {
            expect(CommonPage.sectionNewsAvailable("search").isPresent()).toBeTruthy();
        });
    });

    it('should add the news to favorites on searched news', () => {
        CommonPage.waitPresenceOfElement(CommonPage.sectionNewsAvailable("search")).then(() => {
            CommonPage.addFavoriteNews("search").then(() => {
                CommonPage.waitForAlert();
                CommonPage.acceptAlert().then(() => {
                    CommonPage.waitPresenceOfElement(CommonPage.buttonDisplayed('search', 'add')).then(() => {
                        expect(CommonPage.buttonDisplayed('search', 'add').isPresent()).toBeTruthy();
                    });
                });
            });
        });
    });

    it('should remove the news to favorites on searched news', () => {
        CommonPage.waitPresenceOfElement(CommonPage.sectionNewsAvailable("search")).then(() => {
            CommonPage.removeFavoriteNews("search").then(() => {
                CommonPage.waitForAlert();
                CommonPage.acceptAlert().then(() => {
                    CommonPage.waitPresenceOfElement(CommonPage.buttonDisplayed('search', 'delete')).then(() => {
                        expect(CommonPage.buttonDisplayed('search', 'delete').isPresent()).toBeTruthy();
                    });
                });
            });
        });
    });
});
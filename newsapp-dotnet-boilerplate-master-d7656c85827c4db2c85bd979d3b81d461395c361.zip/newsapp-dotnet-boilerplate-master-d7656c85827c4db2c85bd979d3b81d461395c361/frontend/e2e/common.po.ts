import { browser, by, element, promise, protractor, ElementFinder } from 'protractor';

export class CommonPage {

    static buttonClick(id: string): promise.Promise<any> {
        return element(by.id(id)).click();
    }

    static getText(id: string): promise.Promise<any> {
        return element(by.id(id)).getText();
    }

    static getSectionText(id: string) {
        if (id === 'categoryNews') {
            return element(by.xpath("//div[@id='" + id + "']/div/div/h3[@id='title']/span")).getText();
        }
        return element(by.xpath("//div[@id='" + id + "']/h3[@id='title']/span")).getText();
    }

    static navigateToFavoriteNews() {
        return browser.get('/favorites');
    }

    static navigateToHome() {
        return browser.get('/home');
    }

    static sendKeys(id: string, values: string) {
        element(by.id(id)).clear().then(() => {
            element(by.id(id)).sendKeys(values);
        });
    }

    static waitForAlert(): void {
        browser.wait(protractor.ExpectedConditions.alertIsPresent(), 1000);
    }

    static acceptAlert(): promise.Promise<any> {
        return browser.switchTo().alert().accept();
    }

    static sectionNewsAvailable(section: string) {
        return element(by.css("#" + section + " .card-group .news-card"));
    }


    static addFavoriteNews(section: string): promise.Promise<any> {
        return element(by.css("#" + section + " .card-group  .news-card:nth-child(1) .favorite-btn")).click();
    }

    static removeFavoriteNews(section: string): promise.Promise<any> {
        return element(by.css("#" + section + " .card-group  .news-card:nth-child(1) .unfavorite-btn")).click();
    }

    static buttonDisplayed(section: string, action: string) {
        if (action === "add") {
            return element(by.css("#" + section + " .card-group  .news-card:nth-child(1) .unfavorite-btn"));
        }
        return element(by.css("#" + section + " .card-group  .news-card:nth-child(1) .favorite-btn"));
    }

    static waitPresenceOfElement(elementToWaitFor: ElementFinder): promise.Promise<any> {
        return browser.wait(() => {
            return elementToWaitFor.isPresent();
        })
    }

    static getCurrentUrl(): promise.Promise<any> {
        return browser.getCurrentUrl();
    }

    static selectDropDownOption(option: string): promise.Promise<any> {
        return element(by.xpath('//div[@class="dropdown"]/button')).click().then(() => {
            return element(by.xpath('//button[@class="dropdown-item"]/span[text() = "'+ option +'"]')).click();      
        });        
    }

    static currentDropDownSelectionText(){
        return element(by.xpath('//div[@class="dropdown"]/button')).getText();
    }

    static enterValues(id: string, values: string): promise.Promise<any> {
        return element(by.id(id)).clear().then(() => {
            return element(by.id(id)).sendKeys(values);
        });
    }

    static sectionNewsAvailableCount(section: string): any {
        return element.all(by.css("#" + section + " .card-group .news-card")).count();
    }

}
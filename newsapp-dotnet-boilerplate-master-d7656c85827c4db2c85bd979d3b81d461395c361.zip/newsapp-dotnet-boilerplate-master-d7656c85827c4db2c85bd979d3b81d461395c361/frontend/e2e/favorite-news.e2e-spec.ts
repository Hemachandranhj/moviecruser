import { CommonPage } from './common.po';

describe('Favorite News Page', () => {

    it('should navigate to favorite news page', () => {
        CommonPage.navigateToFavoriteNews()
            .then((url) => {
                CommonPage.getCurrentUrl()
                    .then((url) => {
                        expect(url).toMatch('favorites');
                    });
            });
    });

    it('should see the title for favorite news', () => {
        expect(CommonPage.getSectionText("favNews")).toBe("My Favorites");
    });

    it('should add the news to favorites on top news head lines news', () => {
        CommonPage.navigateToHome().then(() => {
            CommonPage.waitPresenceOfElement(CommonPage.sectionNewsAvailable("headlines")).then(() => {
                CommonPage.addFavoriteNews("headlines").then(() => {
                    CommonPage.waitForAlert();
                    CommonPage.acceptAlert().then(() => {
                        CommonPage.navigateToFavoriteNews().then(() => {
                            expect(CommonPage.sectionNewsAvailable("favorites").isPresent()).toBeTruthy();
                        });
                    });
                });
            });
        });
    });

    it('should remove the news from favorites', () => {
        CommonPage.navigateToFavoriteNews().then(() => {
            CommonPage.waitPresenceOfElement(CommonPage.sectionNewsAvailable("favorites")).then(() => {
                CommonPage.removeFavoriteNews("favorites").then(() => {
                    CommonPage.waitForAlert();
                    CommonPage.acceptAlert().then(() => {
                        expect(CommonPage.getSectionText("favNews")).toBe("My Favorites");
                    });
                });
            });
        });
    });

    it('should display the news by search', () => {
        CommonPage.navigateToFavoriteNews().then(() => {
            CommonPage.waitPresenceOfElement(CommonPage.sectionNewsAvailable("favorites")).then(() => {
                CommonPage.enterValues("search-text", "tamilnadu").then(() => {
                    CommonPage.buttonClick("search-btn").then(() => {
                        CommonPage.getCurrentUrl()
                            .then((url) => {
                                expect(url).toMatch('search');
                                expect(CommonPage.getSectionText("serachNews")).toBe("Search News");
                                expect(CommonPage.sectionNewsAvailable("search").isPresent()).toBeTruthy();
                            });
                    });
                });
            });
        });
    });

});
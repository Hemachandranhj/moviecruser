import { Component, OnInit } from '@angular/core';
import { INewsDetail } from '../providers/models/news-details.interface';
import { NewsService } from '../providers/services/news.service';
import { FavoriteNewsService } from '../providers/services/favoriteNews.service';

@Component({
    selector: 'app-dashboard',
    templateUrl: './dashboard.component.html'
})

export class DashboardComponent implements OnInit {

    topHeadLines: INewsDetail[];
    categoryNews: INewsDetail[];
    newsList: INewsDetail[];
    error: any;
    newsCategory: string[];
    selectedCategory: string;

    constructor(private newsService: NewsService,
        private favoriteNewsService: FavoriteNewsService) {
    }

    ngOnInit() {
        this.newsCategory = ["General", "Business", "Entertainment", "Health", "Science", "Sports", "Technology"];
        this.selectedCategory = "General";
        this.getTopNewsHeadlinesCollection();
        this.getCategoryNews();
    }

    onNewsDetails(): void {
        this.getTopNewsHeadlinesCollection();
        this.getCategoryNews();
    }

    onSelectNewsCategory(category: string): void {
        this.selectedCategory = category;
        this.getCategoryNews();
    }

    displayErrorText(errorMessage): string {
        return errorMessage === '[object ProgressEvent]' ? 'Web api connection issue' : errorMessage;
    }

    private getTopNewsHeadlinesCollection(): void {
        this.favoriteNewsService.get().subscribe((response) => {
            this.newsList = response;
            this.newsService.getTopNewsHeadLines().subscribe(result => {
                this.newsList.forEach((items) => {
                    result.forEach((news) => {
                        if (items.title === news.title) {
                            news.id = items.id;
                        }
                    })
                })
                this.topHeadLines = result;
            }, error => {
                this.error = error.message;
            });
        }, error => {
            this.error = error.message;
        });
    }

    private getCategoryNews(): void {
        this.favoriteNewsService.get().subscribe((response) => {
            this.newsList = response;
            this.newsService.getCategoryNews(this.selectedCategory).subscribe(result => {
                this.newsList.forEach((items) => {
                    result.forEach((news) => {
                        if (items.title === news.title) {
                            news.id = items.id;
                        }
                    })
                })
                this.categoryNews = result;
            }, error => {
                this.error = error.message;
            });
        }, error => {
            this.error = error.message;
        });

    }
}
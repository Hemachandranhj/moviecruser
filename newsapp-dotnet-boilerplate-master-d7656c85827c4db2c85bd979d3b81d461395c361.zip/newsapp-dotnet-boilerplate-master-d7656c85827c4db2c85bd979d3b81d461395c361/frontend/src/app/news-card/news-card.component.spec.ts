import { TestBed } from "@angular/core/testing";
import { of } from "rxjs/observable/of";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { NO_ERRORS_SCHEMA } from "@angular/core";
import { FavoriteNewsService } from "../providers/services/favoriteNews.service";
import { NewsDetail } from "../providers/models/news-details";
import { NewsCardComponent } from "./news-card.component";
import { Observable } from "rxjs";
import {NgxPaginationModule} from 'ngx-pagination';

describe("NewsCardComponent", () => {
  
    let mockFavNewsService: FavoriteNewsService;
    let componentInstance: any;
    let newsDetail: NewsDetail = {
        id: 55,
        sourceId: null,
        sourceName: "Wtop.com",
        author: "The Associated Press",
        title: "Rite Aid, Albertsons call off merger deal ahead of vote",
        description: "Drugstore chain Rite Aid and grocer Albertsons say they have called off their merger deal.",
        url: "https://wtop.com/business-finance/2018/08/rite-aid-albertsons-call-off-merger-deal/",
        urlToImage: "https://wtop.com/wp-content/uploads/2018/08/Rite_Aid_Outlook_Slashed_13237.jpg",
        publishedAt: new Date().toString()
    };

    beforeEach(() => {      
        mockFavNewsService = jasmine.createSpyObj("FavoriteNewsService", ["post", "delete"]);
        ((mockFavNewsService.post) as jasmine.Spy).and.returnValue(of("News added succeesfully in My Favoites"));
        ((mockFavNewsService.delete) as jasmine.Spy).and.returnValue(of("News deleted succeesfully in My Favoites"));
        componentInstance = new NewsCardComponent(mockFavNewsService);
        spyOn(componentInstance.newsEmit, "emit");
    });

    it("should create a component", () => {

        TestBed.configureTestingModule({
            imports: [
                FormsModule,
                ReactiveFormsModule,
                NgxPaginationModule
            ],
            declarations: [NewsCardComponent],
            providers: [
                { provide: FavoriteNewsService, useValue: mockFavNewsService }
            ],
            schemas: [NO_ERRORS_SCHEMA]
        });

        const fixture = TestBed.createComponent(NewsCardComponent);
        const component = fixture.componentInstance;
        expect(component).toBeTruthy();
    });

    it("addFavorites method - should call the service in favorite services as expected", () => {

        // Act
        componentInstance.addFavorites(newsDetail);

        // Assert
        expect(mockFavNewsService.post).toHaveBeenCalledWith(newsDetail);
        expect(componentInstance.newsEmit.emit).toHaveBeenCalled();
    });  

    it("deleteFavorites method - should call the service in favorite services as expected", () => {

        // Act
        componentInstance.deleteFavorites(55);

        // Assert
        expect(mockFavNewsService.delete).toHaveBeenCalledWith(55);
        expect(componentInstance.newsEmit.emit).toHaveBeenCalled();
    });

    describe("call error", () => {

        beforeEach(() => {           
            mockFavNewsService = jasmine.createSpyObj("FavoriteNewsService", ["post", "delete"]);
            ((mockFavNewsService.post) as jasmine.Spy).and.returnValue(Observable.throw(new Error("failure")));
            ((mockFavNewsService.delete) as jasmine.Spy).and.returnValue(Observable.throw(new Error("failure")));
            componentInstance = new NewsCardComponent(mockFavNewsService);
        });

        it("addFavorites method - should call the service in favorite services and throw error captured as expected", () => {

            // Act
            componentInstance.addFavorites(newsDetail);
    
            // Assert
            expect(mockFavNewsService.post).toHaveBeenCalledWith(newsDetail);
            expect(componentInstance.error).not.toBeNull();
        });  
    
        it("deleteFavorites method - should call the service in favorite services and throw error captured as expected", () => {
    
            // Act
            componentInstance.deleteFavorites(55);
    
            // Assert
            expect(mockFavNewsService.delete).toHaveBeenCalledWith(55);
            expect(componentInstance.error).not.toBeNull();
        });   

    });
});

import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { INewsDetail } from '../providers/models/news-details.interface';
import { FavoriteNewsService } from '../providers/services/favoriteNews.service';

@Component({
    selector: 'app-news-card',
    templateUrl: './news-card.component.html',
    styleUrls: ['./news-card.component.css']
})

export class NewsCardComponent {

    @Input() newsCollection: INewsDetail[];
    @Input() section: string;
    @Input() displayItemsPerPage: number = 8;
    @Output() newsEmit = new EventEmitter<any>();

    currentPage: number = 1;
    error: any;

    constructor(private favoriteNewsService: FavoriteNewsService) { }

    addFavorites(news: any): void {
        this.favoriteNewsService.post(news).subscribe((response) => {
            window.alert(response);
            this.newsEmit.emit();
        }, error => {
            this.error = error;
        });
    }

    deleteFavorites(newsId: number): void {
        this.favoriteNewsService.delete(newsId).subscribe((response) => {
            window.alert(response);
            this.newsEmit.emit();
        }, error => {
            this.error = error;
        });
    }
}
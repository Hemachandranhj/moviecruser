import { Component, OnInit } from '@angular/core';
import { INewsDetail } from '../providers/models/news-details.interface';
import { NewsService } from '../providers/services/news.service';
import { FavoriteNewsService } from '../providers/services/favoriteNews.service';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'app-search-news',
    templateUrl: './search-news.component.html'
})

export class SearchNewsComponent implements OnInit {

    searchNews: INewsDetail[];
    newsList: INewsDetail[];
    error: any;
    searchText: string;

    constructor(private newsService: NewsService,
        private favoriteNewsService: FavoriteNewsService,
        private route: ActivatedRoute) {
    }

    ngOnInit() {
        this.route.params.subscribe(params => {
            this.searchText = params["searchText"];
            this.getSearchNews();
        });
    }

    onNewsDetails(): void {
        this.getSearchNews();
    }

    displayErrorText(errorMessage): string {
        return errorMessage === '[object ProgressEvent]' ? 'Web api connection issue' : errorMessage
    }

    private getSearchNews(): void {
        this.favoriteNewsService.get().subscribe((response) => {
            this.newsList = response;
            this.newsService.search(this.searchText).subscribe(result => {
                this.newsList.forEach((items) => {
                    result.forEach((news) => {
                        if (items.title === news.title) {
                            news.id = items.id;
                        }
                    })
                })
                this.searchNews = result;
            }, error => {
                this.error = error.message;
            });
        }, error => {
            this.error = error.message;
        });
    }
}
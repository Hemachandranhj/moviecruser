import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HeaderComponent } from "./header/header.component";
import { DashboardComponent } from "./dashboard/dashboard.component";
import { FormsModule, ReactiveFormsModule } from '../../node_modules/@angular/forms';
import { HttpClientModule } from '../../node_modules/@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { NewsService } from './providers/services/news.service';
import { FavoriteNewsService } from './providers/services/favoriteNews.service';
import { NewsCardComponent } from './news-card/news-card.component';
import { SearchNewsComponent } from './search-news/search-news.component';
import { FavoriteNewsComponent } from './favorite-news/favorite-news.component';
import {NgxPaginationModule} from 'ngx-pagination';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    DashboardComponent,
    NewsCardComponent,
    SearchNewsComponent,
    FavoriteNewsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    AppRoutingModule,
    NgxPaginationModule
  ],
  providers: [    
    NewsService,
    FavoriteNewsService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { RouterModule, Routes } from "@angular/router";
import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule } from "@angular/forms";

import { DashboardComponent } from "./dashboard/dashboard.component";
import { SearchNewsComponent } from "./search-news/search-news.component";
import { FavoriteNewsComponent } from "./favorite-news/favorite-news.component";

const routes: Routes = [
    { path: '', redirectTo: '/home', pathMatch: 'full' },
    { path: 'home', component: DashboardComponent},   
    { path: 'search/:searchText', component: SearchNewsComponent},
    { path: 'favorites', component: FavoriteNewsComponent},     
    { path: "**", redirectTo: '/home', pathMatch: 'full' }
];

@NgModule({    
    imports:[BrowserModule, FormsModule, RouterModule.forRoot(routes)],
    exports: [RouterModule]
})

export class AppRoutingModule {}






import { TestBed } from "@angular/core/testing";
import { of } from "rxjs/observable/of";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { NO_ERRORS_SCHEMA } from "@angular/core";
import { FavoriteNewsService } from "../providers/services/favoriteNews.service";
import { NewsDetail } from "../providers/models/news-details";
import { FavoriteNewsComponent } from "./favorite-news.component";
import { Observable } from "rxjs";

describe("FavoriteNewsComponent", () => {
  
    let mockFavNewsService: FavoriteNewsService;
    let componentInstance: any;
    let newsDetail: NewsDetail = {
        id: 55,
        sourceId: null,
        sourceName: "Wtop.com",
        author: "The Associated Press",
        title: "Rite Aid, Albertsons call off merger deal ahead of vote",
        description: "Drugstore chain Rite Aid and grocer Albertsons say they have called off their merger deal.",
        url: "https://wtop.com/business-finance/2018/08/rite-aid-albertsons-call-off-merger-deal/",
        urlToImage: "https://wtop.com/wp-content/uploads/2018/08/Rite_Aid_Outlook_Slashed_13237.jpg",
        publishedAt: new Date().toString()
    };
    let newsCollection = [newsDetail];

    beforeEach(() => {      
        mockFavNewsService = jasmine.createSpyObj("FavoriteNewsService", ["get"]);
        ((mockFavNewsService.get) as jasmine.Spy).and.returnValue(of(newsCollection));
        componentInstance = new FavoriteNewsComponent(mockFavNewsService);
    });

    it("should create a component", () => {

        TestBed.configureTestingModule({
            imports: [
                FormsModule,
                ReactiveFormsModule
            ],
            declarations: [FavoriteNewsComponent],
            providers: [
                { provide: FavoriteNewsService, useValue: mockFavNewsService }
            ],
            schemas: [NO_ERRORS_SCHEMA]
        });

        const fixture = TestBed.createComponent(FavoriteNewsComponent);
        const component = fixture.componentInstance;
        expect(component).toBeTruthy();
    });

    it("ngOninit method - should call the service in favorite services as expected", () => {

        // Act
        componentInstance.ngOnInit();

        // Assert
        expect(mockFavNewsService.get).toHaveBeenCalled();
        expect(componentInstance.favoriteNews.length).toBe(1);
    });

    it("onNewsDetails method - should call the service in favorite services as expected", () => {

        // Act
        componentInstance.onNewsDetails();

        // Assert
        expect(mockFavNewsService.get).toHaveBeenCalled();
        expect(componentInstance.favoriteNews.length).toBe(1);
    });  

    it("displayErrorText method - should return error message as expected", () => {

        // Act
        let error = componentInstance.displayErrorText("Server Error Occured");

        // Assert
        expect(error).toBe("Server Error Occured");
    });

    describe("call error", () => {

        beforeEach(() => {           
            mockFavNewsService = jasmine.createSpyObj("FavoriteNewsService", ["get"]);
            ((mockFavNewsService.get) as jasmine.Spy).and.returnValue(Observable.throw(new Error("failure")));
            componentInstance = new FavoriteNewsComponent(mockFavNewsService);
        });

        it("ngOninit method - should call the service in favorite services and throw error captured as expected", () => {

            // Act
            componentInstance.ngOnInit();
    
            // Assert
            expect(mockFavNewsService.get).toHaveBeenCalled();
            expect(componentInstance.error).not.toBeNull();    
        });    

    });
});

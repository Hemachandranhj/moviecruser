import { Component, OnInit } from '@angular/core';
import { INewsDetail } from '../providers/models/news-details.interface';
import { FavoriteNewsService } from '../providers/services/favoriteNews.service';

@Component({
    selector: 'app-favorite-news',
    templateUrl: './favorite-news.component.html'
})

export class FavoriteNewsComponent implements OnInit {

    favoriteNews: INewsDetail[];
    error: any;

    constructor(private favoriteNewsService: FavoriteNewsService) {
    }

    ngOnInit() {
        this.getfavoriteNews();
    }

    onNewsDetails(): void {
        this.getfavoriteNews();
    }

    displayErrorText(errorMessage): string {
        return errorMessage === '[object ProgressEvent]' ? 'Web api connection issue' : errorMessage
    }

    private getfavoriteNews(): void {
        this.favoriteNewsService.get().subscribe((response) => {
            this.favoriteNews = response;            
        }, error => {
            this.error = error.message;
        });
    }
}
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { map, catchError } from "rxjs/operators";
import { Observable } from "rxjs"
import { NewsDetail } from "../models/news-details";
import { environment } from "../../../environments/environment.prod";
import { INewsDetail } from "../models/news-details.interface";

@Injectable()
export class FavoriteNewsService {

    apiUrl = environment.favoriteNewsUrl;
    httpOptions = {
        headers: new HttpHeaders({
            'Content-Type': 'application/json'
        })
    };

    constructor(private http: HttpClient) { }

    // method for getting favorite news
    get(): Observable<Array<INewsDetail>> {
        return this.http.get(this.apiUrl).pipe(map((response: any) => {
            return this.mapNewsResults(response);
        }),
            catchError((error: any): any => {
                throw new Error(error.error);
            }));
    }

    // method for adding a new favorite news
    post(newsDetails: NewsDetail): Observable<any> {
        var news = {
            SourceId: newsDetails.sourceId,
            SourceName: newsDetails.sourceName,
            Author: newsDetails.author,
            Description: newsDetails.description,
            Title: newsDetails.title,
            Url: newsDetails.url,
            UrlToImage: newsDetails.urlToImage,
            PublishedAt: newsDetails.publishedAt
        }
        var body = JSON.stringify(news);
        return this.http.post(this.apiUrl, body, this.httpOptions).pipe(map((response: any) => {
            return "News added successfully in My Favorites";
        }),
            catchError((error: any): any => {
                return Observable.of(error);
            }));

    }

    // method to delete the news from favorites
    delete(id: number): Observable<boolean> {
        var url = this.apiUrl + "/" + id;
        return this.http.delete(url).pipe(map((response: any): any => {
            if (response == true) {
                return "Favorite news deleted successfully.";
            }
            return "Failed to delete a favorite news.";
        }),
            catchError((error: any): any => {
                throw error.error;
            }));
    }

    // method for mapping news results
    private mapNewsResults(response: any): any {
        var newsList = [];
        response.forEach(item => {
            newsList.push(this.mapNewsDetails(item));
        });
        return newsList;
    }

    // method for mapping a news to model
    private mapNewsDetails(details: any): INewsDetail {
        var newsDetails = new NewsDetail();
        newsDetails.sourceId = details.sourceId;
        newsDetails.sourceName = details.sourceName;
        newsDetails.author = details.author;
        newsDetails.description = details.description;
        newsDetails.title = details.title;
        newsDetails.url = details.url;
        newsDetails.urlToImage = details.urlToImage;
        newsDetails.publishedAt = details.publishedAt;
        newsDetails.id = details.id;

        return newsDetails;
    }
}

import { TestBed } from "@angular/core/testing";
import { HttpClientTestingModule, HttpTestingController } from "@angular/common/http/testing";

import { FavoriteNewsService } from "../services/favoriteNews.service";
import { environment } from "../../../environments/environment.prod";
import { Observable } from "rxjs";
import { NewsDetail } from "../models/news-details";
import { of } from "rxjs/observable/of";


describe("Favorite News Service", () => {

    const apiBaseUrl: string = environment.favoriteNewsUrl;
    let mockFavNewsService: FavoriteNewsService;
    let mockHttp: any;   

    let newsDetail: NewsDetail = {        
        id: 55,
        sourceId: null,
        sourceName: "Wtop.com",
        author: "The Associated Press",
        title: "Rite Aid, Albertsons call off merger deal ahead of vote",
        description: "Drugstore chain Rite Aid and grocer Albertsons say they have called off their merger deal.",
        url: "https://wtop.com/business-finance/2018/08/rite-aid-albertsons-call-off-merger-deal/",
        urlToImage: "https://wtop.com/wp-content/uploads/2018/08/Rite_Aid_Outlook_Slashed_13237.jpg",
        publishedAt: new Date().toString()
    };

    let newsCollection = [newsDetail];

    beforeEach(() => {      

        TestBed.configureTestingModule({
            imports: [
                HttpClientTestingModule
            ],
            providers: [
                FavoriteNewsService               
            ]
        });

        mockFavNewsService = TestBed.get(FavoriteNewsService);
        mockHttp = TestBed.get(HttpTestingController);
    });

    it("should call the method get on favorite news services as expected", () => {

        mockFavNewsService.get().subscribe(data => {
            expect(data[0].id).toBe(newsCollection[0].id);
            expect(data[0].sourceId).toBe(newsCollection[0].sourceId);
            expect(data[0].sourceName).toBe(newsCollection[0].sourceName);
            expect(data[0].author).toBe(newsCollection[0].author);
            expect(data[0].description).toBe(newsCollection[0].description);
            expect(data[0].urlToImage).toBe(newsCollection[0].urlToImage);
            expect(data[0].url).toBe(newsCollection[0].url);
        });

        const req = mockHttp.expectOne(apiBaseUrl);
        expect(req.request.method).toEqual('GET');
        req.flush(newsCollection);
        mockHttp.verify();
    });

    it("should call the method get on favorite news services throws API error as expected", () => {

        mockFavNewsService.get().subscribe( {
            error(err) {
                expect(of(err)).toBeTruthy();
                expect(err).not.toBeNull();
            }
        });

        const req = mockHttp.expectOne(apiBaseUrl);
        expect(req.request.method).toEqual('GET');      
        req.flush({ errorMessage: 'Server Error occured' }, { status: 400, statusText: "Server Error"});
        mockHttp.verify();
    });

    it("should call the method post favorite news services as expected", () => {

        mockFavNewsService.post(newsDetail).subscribe(response => {
            expect(response).toBe("News added successfully in My Favorites");
        });

        const req = mockHttp.expectOne(apiBaseUrl);
        expect(req.request.method).toEqual('POST');
        req.flush(newsCollection);
        mockHttp.verify();
    });

    it("should call the method post on favorite news services throws API error as expected", () => {

        mockFavNewsService.post(newsDetail).subscribe( {
            error(err) {
                expect(of(err)).toBeTruthy();
                expect(err).not.toBeNull();
            }
        });

        const req = mockHttp.expectOne(apiBaseUrl);
        expect(req.request.method).toEqual('POST');      
        req.flush({ errorMessage: 'Server Error occured' }, { status: 400, statusText: "Server Error"});
        mockHttp.verify();
    });

    it("should call the method delete on favorite news services as expected", () => {

        mockFavNewsService.delete(55).subscribe(response => {
            expect(<boolean>response).toBeTruthy();            
        });

        const req = mockHttp.expectOne(apiBaseUrl + "/55");
        expect(req.request.method).toEqual('DELETE');
        req.flush(Observable.of(true));
        mockHttp.verify();
    });

    it("should call the method delete on favorite news services throws API error as expected", () => {

        mockFavNewsService.delete(55).subscribe( {
            error(err) {
                expect(of(err)).toBeTruthy();
                expect(err).not.toBeNull();
            }
        });

        const req = mockHttp.expectOne(apiBaseUrl + "/55");
        expect(req.request.method).toEqual('DELETE');      
        req.flush({ errorMessage: 'Server Error occured' }, { status: 400, statusText: "Server Error"});
        mockHttp.verify();
    });
});

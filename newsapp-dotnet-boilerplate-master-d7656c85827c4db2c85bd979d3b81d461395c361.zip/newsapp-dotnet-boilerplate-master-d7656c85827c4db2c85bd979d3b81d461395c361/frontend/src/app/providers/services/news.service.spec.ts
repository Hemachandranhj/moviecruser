import { TestBed } from "@angular/core/testing";
import { HttpClientTestingModule, HttpTestingController } from "@angular/common/http/testing";

import { NewsService } from "./news.service";
import { environment } from "../../../environments/environment.prod";
import { of } from "rxjs/observable/of";


describe("NewsService", () => {

    const apiBaseUrl: string = environment.newsUrl;
    let mockNewsService: NewsService;
    let mockHttp: any;

    let newsCollection =
        [{
            source: {
                id: null,
                name: "Wtop.com"
            },
            author: "The Associated Press",
            title: "Rite Aid, Albertsons call off merger deal ahead of vote",
            description: "Drugstore chain Rite Aid and grocer Albertsons say they have called off their merger deal.",
            url: "https://wtop.com/business-finance/2018/08/rite-aid-albertsons-call-off-merger-deal/",
            urlToImage: "https://wtop.com/wp-content/uploads/2018/08/Rite_Aid_Outlook_Slashed_13237.jpg",
            publishedAt: new Date()
        }];

    let newsResponse = {
        status: "ok",
        totalResults: 10,
        articles: newsCollection,
    };

    beforeEach(() => {      

        TestBed.configureTestingModule({
            imports: [
                HttpClientTestingModule
            ],
            providers: [
                NewsService               
            ]
        });

        mockNewsService = TestBed.get(NewsService);
        mockHttp = TestBed.get(HttpTestingController);
    });

    it("should call the method getTopNewsHeadLines on news services as expected", () => {

        mockNewsService.getTopNewsHeadLines().subscribe(data => {
            expect(data[0].sourceId).toBe(newsCollection[0].source.id);
            expect(data[0].sourceName).toBe(newsCollection[0].source.name);
            expect(data[0].author).toBe(newsCollection[0].author);
            expect(data[0].description).toBe(newsCollection[0].description);
            expect(data[0].urlToImage).toBe(newsCollection[0].urlToImage);
            expect(data[0].url).toBe(newsCollection[0].url);
        });

        const req = mockHttp.expectOne(apiBaseUrl + "gettopnewsheadlines");
        expect(req.request.method).toEqual('GET');
        req.flush(newsResponse);
        mockHttp.verify();
    });

    it("should call the method getTopNewsHeadLines on news services throws API error as expected", () => {

        mockNewsService.getTopNewsHeadLines().subscribe( {
            error(err) {
                expect(of(err)).toBeTruthy();
                expect(err).not.toBeNull();
            }
        });

        const req = mockHttp.expectOne(apiBaseUrl + "gettopnewsheadlines");
        expect(req.request.method).toEqual('GET');      
        req.flush({ errorMessage: 'Server Error occured' }, { status: 400, statusText: "Server Error"});
        mockHttp.verify();
    });

    it("should call the method getCategoryNews on news services as expected", () => {

        mockNewsService.getCategoryNews("business").subscribe(data => {
            expect(data[0].sourceId).toBe(newsCollection[0].source.id);
            expect(data[0].sourceName).toBe(newsCollection[0].source.name);
            expect(data[0].author).toBe(newsCollection[0].author);
            expect(data[0].description).toBe(newsCollection[0].description);
            expect(data[0].urlToImage).toBe(newsCollection[0].urlToImage);
            expect(data[0].url).toBe(newsCollection[0].url);
        });

        const req = mockHttp.expectOne(apiBaseUrl + "business");
        expect(req.request.method).toEqual('GET');
        req.flush(newsResponse);
        mockHttp.verify();
    });

    it("should call the method getCategoryNews on news services throws API error as expected", () => {

        mockNewsService.getCategoryNews("business").subscribe( {
            error(err) {
                expect(of(err)).toBeTruthy();
                expect(err).not.toBeNull();
            }
        });

        const req = mockHttp.expectOne(apiBaseUrl + "business");
        expect(req.request.method).toEqual('GET');      
        req.flush({ errorMessage: 'Server Error occured' }, { status: 400, statusText: "Server Error"});
        mockHttp.verify();
    });

    it("should call the method search on news services as expected", () => {

        mockNewsService.search("tamilnadu").subscribe(data => {
            expect(data[0].sourceId).toBe(newsCollection[0].source.id);
            expect(data[0].sourceName).toBe(newsCollection[0].source.name);
            expect(data[0].author).toBe(newsCollection[0].author);
            expect(data[0].description).toBe(newsCollection[0].description);
            expect(data[0].urlToImage).toBe(newsCollection[0].urlToImage);
            expect(data[0].url).toBe(newsCollection[0].url);
        });

        const req = mockHttp.expectOne(apiBaseUrl + "search/tamilnadu");
        expect(req.request.method).toEqual('GET');
        req.flush(newsResponse);
        mockHttp.verify();
    });

    it("should call the method search on news services throws API error as expected", () => {

        mockNewsService.search("tamilnadu").subscribe( {
            error(err) {
                expect(of(err)).toBeTruthy();
                expect(err).not.toBeNull();
            }
        });

        const req = mockHttp.expectOne(apiBaseUrl + "search/tamilnadu");
        expect(req.request.method).toEqual('GET');      
        req.flush({ errorMessage: 'Server Error occured' }, { status: 400, statusText: "Server Error"});
        mockHttp.verify();
    });
});

import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { map, catchError } from "rxjs/operators";
import { Observable } from "rxjs";
import { INewsDetail } from "../models/news-details.interface";
import { NewsDetail } from "../models/news-details";
import { environment } from "../../../environments/environment.prod";

@Injectable()
export class NewsService {
   
    apiUrl: string;

    constructor(private http: HttpClient) {
        this.apiUrl = environment.newsUrl;
    }

    // method for getting all news
    getTopNewsHeadLines(): Observable<Array<INewsDetail>> {
        var url = this.apiUrl + "gettopnewsheadlines";
        return this.http.get(url).pipe(map((response: any) => {
            return this.mapNewsResults(response.articles);
        }),
        catchError((error): any => {
          throw new Error(error.error);
        }));
    }

    // method for getting category news
    getCategoryNews(category: string): Observable<Array<INewsDetail>> {
        var url = this.apiUrl + category;
        return this.http.get(url).pipe(map((response: any) => {
            return this.mapNewsResults(response.articles);
        }),
        catchError((error): any => {
          throw new Error(error.error);
        }));
    }

    // method for searching news
    search(searchQuery: string): Observable<Array<INewsDetail>> {
        var url = this.apiUrl +  "search/" + searchQuery;
        return this.http.get(url).pipe(map((response: any) => {
            return this.mapNewsResults(response.articles);
        }),
        catchError((error): any => {
          throw new Error(error.error);
        }));
    }

    // method for mapping news results
    private mapNewsResults(response: any): any {        
        var newsList = [];
        response.forEach(item => {
            newsList.push(this.mapNewsDetails(item));            
        });       
        return newsList;
    }

    // method for mapping a news to model
    private mapNewsDetails(details: any): INewsDetail {
        var newsDetails = new NewsDetail();
        newsDetails.sourceId = details.source.id;
        newsDetails.sourceName = details.source.name;
        newsDetails.author = details.author;
        newsDetails.description = details.description;
        newsDetails.title = details.title;
        newsDetails.url = details.url;
        newsDetails.urlToImage = details.urlToImage;
        newsDetails.publishedAt = details.publishedAt;

        return newsDetails;
    }
}

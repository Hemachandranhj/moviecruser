export interface INewsDetail {
    id: number,
    sourceId: string,
    sourceName: string,
    author: string,
    title: string,
    description: string,
    url: string,
    urlToImage: string,
    publishedAt: string
}
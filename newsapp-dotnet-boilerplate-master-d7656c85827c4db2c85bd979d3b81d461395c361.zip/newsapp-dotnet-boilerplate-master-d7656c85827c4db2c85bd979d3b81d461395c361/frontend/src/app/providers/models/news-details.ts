import { INewsDetail } from "./news-details.interface";

export class NewsDetail implements INewsDetail {
    id: number;
    sourceId: string;
    sourceName: string;
    author: string;
    title: string;
    description: string;
    url: string;
    urlToImage: string;
    publishedAt: string;
}
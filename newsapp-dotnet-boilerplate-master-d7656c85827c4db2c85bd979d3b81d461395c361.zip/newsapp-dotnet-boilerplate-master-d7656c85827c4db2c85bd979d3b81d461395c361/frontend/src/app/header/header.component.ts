import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";

@Component({
    selector: 'app-header',
    templateUrl: "./header.component.html",
})

export class HeaderComponent implements OnInit {

    newsSearch: string;

    constructor(private router: Router) { }

    // On init to reset the search text
    ngOnInit() {
        this.resetSearch();
    }

    // method to search the news
    onSearch() {
        if (this.newsSearch === '') {
            this.router.navigate(['/home']);
            return;
        }
        this.router.navigate(['/search', this.newsSearch]);
        this.resetSearch();
    }

    // method to reset the search text
    private resetSearch(): void {
        this.newsSearch = '';
    }
}
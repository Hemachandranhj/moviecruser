import { Router } from "@angular/router";
import { HeaderComponent } from "./header.component";
import { TestBed } from "../../../node_modules/@angular/core/testing";
import { FormsModule, ReactiveFormsModule } from "../../../node_modules/@angular/forms";
import { NO_ERRORS_SCHEMA } from "../../../node_modules/@angular/core";


describe("HeaderComponent", () => {
  
    let router: Router;
    let componentInstance: any;
    const searchText ="TamilNadu";   

    beforeEach(() => {      

        router = jasmine.createSpyObj("router", ["navigate"]);

        componentInstance = new HeaderComponent(router);
    });

    it("should create a component", () => {

        TestBed.configureTestingModule({
            imports: [
                FormsModule,
                ReactiveFormsModule
            ],
            declarations: [HeaderComponent],
            providers: [
                { provide: Router, useValue: router }
            ],
            schemas: [NO_ERRORS_SCHEMA]
        });

        const fixture = TestBed.createComponent(HeaderComponent);
        const component = fixture.componentInstance;
        expect(component).toBeTruthy();
    });

    it("should reset the search text on ngOnInit method as expected", () => {

        // Arrange
        componentInstance.newsSearch = searchText;
        
        // Act
        componentInstance.ngOnInit();

        // Assert
        expect(componentInstance.newsSearch).toBe("");
    });

    it("should call the search method with search text as expected", () => {

        // Arrange
        componentInstance.newsSearch = searchText;
        
        // Act
        componentInstance.onSearch();

        // Assert
        expect(router.navigate).toHaveBeenCalledWith(['/search', searchText]);
        expect(componentInstance.newsSearch).toBe("");
    });

    it("should call the search method without search text as expected", () => {

        // Arrange
        componentInstance.newsSearch = "";
        
        // Act
        componentInstance.onSearch();

        // Assert
        expect(router.navigate).toHaveBeenCalledWith(['/home']);
    });
});

export const environment = {
  production: true,  
  newsUrl: 'http://localhost:55375/api/News/',
  favoriteNewsUrl: 'http://localhost:55375/api/FavoriteNews',
};
